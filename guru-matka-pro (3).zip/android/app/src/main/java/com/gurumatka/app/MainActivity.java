package com.gurumatka.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
