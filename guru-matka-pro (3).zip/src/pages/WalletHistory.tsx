import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, History, TrendingUp, Loader2, ArrowUpCircle, ArrowDownCircle, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { firebaseService } from '../services/firebaseService';
import { useAuth } from '../hooks/useAuth';
import { Transaction } from '../types';

export default function WalletHistoryScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const unsubscribe = firebaseService.getTransactions(user.uid, (fetchedTransactions) => {
      setTransactions(fetchedTransactions);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">Passbook</h2>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-bold uppercase tracking-widest">Loading History...</p>
          </div>
        ) : transactions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400 space-y-4">
            <History size={64} className="opacity-20" />
            <p className="font-bold text-lg italic uppercase tracking-widest">No transactions found</p>
          </div>
        ) : (
          transactions.map((tx, index) => (
            <motion.div
              key={tx.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden flex flex-col"
            >
              <div className="p-5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                    (tx.type === 'DEPOSIT' || tx.type === 'WIN' || tx.type === 'BONUS') ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                  }`}>
                    {(tx.type === 'DEPOSIT' || tx.type === 'WIN' || tx.type === 'BONUS') ? <ArrowUpCircle size={32} /> : <ArrowDownCircle size={32} />}
                  </div>
                  <div>
                    <h3 className="font-black text-xl text-dark uppercase tracking-tight">
                      {tx.type === 'DEPOSIT' ? 'Deposit (Credit)' : 
                       tx.type === 'WITHDRAW' ? 'Withdrawal (Debit)' :
                       tx.type === 'WIN' ? 'Game Win (Credit)' :
                       tx.type === 'BID' ? 'Bet Play (Debit)' : 'Bonus (Credit)'}
                    </h3>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                      {tx.timestamp?.toDate?.()?.toLocaleString() || 'Recent'}
                    </p>
                  </div>
                </div>
                <div className="text-right flex flex-col items-end gap-2">
                  <p className={`text-2xl font-black ${(tx.type === 'DEPOSIT' || tx.type === 'WIN' || tx.type === 'BONUS') ? 'text-green-600' : 'text-red-600'}`}>
                    {(tx.type === 'DEPOSIT' || tx.type === 'WIN' || tx.type === 'BONUS') ? '+' : '-'}₹{tx.amount}
                  </p>
                  <div className="flex items-center justify-end gap-1">
                    {tx.status === 'PENDING' && <Clock size={12} className="text-blue-500" />}
                    {tx.status === 'APPROVED' && <CheckCircle2 size={12} className="text-green-500" />}
                    {tx.status === 'REJECTED' && <XCircle size={12} className="text-red-500" />}
                    <span className={`text-[11px] font-black uppercase tracking-widest ${
                      tx.status === 'APPROVED' ? 'text-green-500' : 
                      tx.status === 'REJECTED' ? 'text-red-500' : 'text-blue-500'
                    }`}>
                      {tx.status}
                    </span>
                  </div>
                </div>
              </div>
              {(tx.upiId || tx.description) && (
                <div className="bg-gray-50/50 px-6 py-3 text-xs font-black text-gray-500 uppercase tracking-[0.1em] border-t border-gray-100 space-y-1">
                  {tx.upiId && <div>UPI ID: {tx.upiId}</div>}
                  {tx.description && <div>Note: {tx.description}</div>}
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>
    </Layout>
  );
}
