import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, MessageSquare, Loader2, CheckCircle2, Wallet, CreditCard, AlertCircle } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { SUPPORT_WHATSAPP } from '../constants';
import { useAuth } from '../hooks/useAuth';
import { firebaseService } from '../services/firebaseService';
import { db } from '../firebase';
import { doc, onSnapshot, updateDoc, increment, addDoc, collection, Timestamp } from 'firebase/firestore';
import { GlobalSettings } from '../types';
import { QRCodeSVG } from 'qrcode.react';

export default function WalletScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [amount, setAmount] = useState('');
  const [upiId, setUpiId] = useState('');
  const [step, setStep] = useState<'amount' | 'qr' | 'success' | 'withdraw'>('amount');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<GlobalSettings | null>(null);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes
  const [paymentStatus, setPaymentStatus] = useState<'IDLE' | 'PENDING' | 'SUCCESS' | 'FAILED'>('IDLE');

  const isWithdrawMode = location.pathname === '/withdraw';
  const quickAmounts = [100, 200, 500, 1000, 2000, 5000];

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) setSettings(snap.data() as any);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (isWithdrawMode) {
      setStep('withdraw');
    } else {
      setStep('amount');
    }
  }, [isWithdrawMode]);

  useEffect(() => {
    let timer: any;
    if (step === 'qr' && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setError('Payment session expired. Please try again.');
      setStep('amount');
    }
    return () => clearInterval(timer);
  }, [step, timeLeft]);

  const handleGatewayPayment = async (gateway: string) => {
    if (!user || !amount || !settings) return;
    setLoading(true);
    setError(null);
    
    // In a real app, you would call your backend to create an order
    // and then open the gateway's checkout.
    // For this demo, we'll simulate the automated process.
    
    try {
      if (gateway === 'UPIGATEWAY') {
        setStep('qr');
        setTimeLeft(120);
      } else {
        // Mocking other gateways for now
        alert(`${gateway} Integration: In a production app, this would redirect to ${gateway} checkout.`);
        setLoading(false);
      }
    } catch (err: any) {
      setError(err.message || 'Payment initialization failed');
      setLoading(false);
    }
  };

  const verifyPayment = async () => {
    if (!user || !amount) return;
    setLoading(true);
    
    // Simulate payment verification
    // In reality, you'd poll the gateway API or wait for a webhook
    setTimeout(async () => {
      try {
        // Mock success for demo
        await updateDoc(doc(db, 'users', user.uid), {
          walletBalance: increment(Number(amount))
        });
        
        await addDoc(collection(db, 'transactions'), {
          userId: user.uid,
          amount: Number(amount),
          type: 'DEPOSIT',
          status: 'COMPLETED',
          description: 'Automated Gateway Deposit',
          timestamp: Timestamp.now()
        });

        setStep('success');
      } catch (err: any) {
        setError('Verification failed. If you paid, please contact support.');
      } finally {
        setLoading(false);
      }
    }, 2000);
  };

  const handleWithdrawRequest = async () => {
    if (!user || !amount || !upiId) {
      setError('Please fill all fields');
      return;
    }
    if (Number(amount) < 500) {
      setError('Minimum withdrawal is ₹500');
      return;
    }
    if (Number(amount) > (user.walletBalance || 0)) {
      setError('Insufficient balance');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await firebaseService.requestWithdraw(user.uid, Number(amount), upiId);
      setStep('success');
    } catch (err: any) {
      console.error('Error submitting withdrawal:', err);
      setError(err.message || 'Withdrawal request failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">
            {isWithdrawMode ? 'Withdraw Funds' : 'Add Amount'}
          </h2>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {error && (
          <div className="bg-red-500/10 border border-red-500/50 p-4 rounded-xl flex items-center gap-3 text-red-500 font-bold">
            <AlertCircle size={20} />
            <p>{error}</p>
          </div>
        )}

        {step === 'amount' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-red-600 text-white py-3 px-4 rounded-xl text-center font-black text-lg tracking-widest shadow-lg shadow-red-600/20">
              कम से कम आप 100 रुपए से ऐड कर सकते है
            </div>

            <div className="flex justify-center">
              <div className="relative w-48 h-48 bg-primary rounded-full flex flex-col items-center justify-center border-4 border-white shadow-2xl overflow-hidden">
                <img 
                  src="https://picsum.photos/seed/guru/200/200" 
                  alt="Logo" 
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-primary/40 backdrop-blur-[2px]">
                  <span className="text-4xl font-black tracking-tighter text-accent">गुरु</span>
                  <span className="text-4xl font-black tracking-tighter text-white">मटका</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <input
                type="number"
                placeholder="Enter Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-white border-2 border-primary/20 rounded-2xl py-5 px-6 focus:outline-none focus:border-primary transition-all text-2xl font-black text-center shadow-inner"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              {quickAmounts.map((amt) => (
                <button
                  key={amt}
                  onClick={() => setAmount(amt.toString())}
                  className="bg-header text-white py-3 rounded-xl font-black text-lg shadow-lg shadow-header/20 active:scale-95 transition-all"
                >
                  {amt}
                </button>
              ))}
            </div>

            <button 
              onClick={() => {
                if (Number(amount) >= 100) {
                  if (settings?.paymentMode === 'GATEWAY') {
                    // If multiple gateways, maybe show a selector, but for now we'll use the first active one
                    const firstGateway = settings.activeGateways?.[0] || 'UPIGATEWAY';
                    handleGatewayPayment(firstGateway);
                  } else {
                    setStep('qr');
                  }
                }
              }}
              disabled={!amount || Number(amount) < 100 || !settings}
              className="w-full bg-header text-white py-5 rounded-2xl font-black text-xl shadow-xl shadow-header/30 active:scale-95 transition-all uppercase tracking-widest disabled:opacity-50"
            >
              {settings?.paymentMode === 'GATEWAY' ? 'PAY SECURELY ( आगे बढ़ें )' : 'PAY BY QRCODE ( आगे बढ़ें )'}
            </button>
          </motion.div>
        )}

        {step === 'qr' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-8 rounded-3xl shadow-2xl border border-gray-100 flex flex-col items-center text-center space-y-6"
          >
            <div className="flex flex-col items-center">
              <h3 className="text-2xl font-black text-dark uppercase tracking-widest">SCAN & PAY</h3>
              <div className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-[10px] font-black mt-2">
                EXPIRES IN: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
              </div>
            </div>

            <div className="w-64 h-64 bg-white rounded-2xl flex items-center justify-center border-4 border-primary/10 shadow-xl p-4">
              {settings?.paymentMode === 'GATEWAY' ? (
                <QRCodeSVG 
                  value={`upi://pay?pa=${settings?.upiGatewayMerchantId || settings?.upiId || 'ajsachin992@okaxis'}&pn=GuruMatka&am=${amount}&tr=${Date.now()}`}
                  size={220}
                  level="H"
                  includeMargin={true}
                />
              ) : (
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${settings?.upiId || 'ajsachin992@okaxis'}&pn=GuruMatka&am=${amount}`} 
                  alt="QR Code" 
                  className="w-full h-full"
                  referrerPolicy="no-referrer"
                />
              )}
            </div>
            
            <p className="text-gray-500 font-bold text-lg">Amount: <span className="text-dark text-2xl font-black">₹{amount}</span></p>
            
            <div className="w-full space-y-4 pt-4 border-t border-gray-100">
              <p className="text-red-500 font-black text-sm uppercase tracking-widest">*महत्वपूर्ण सूचना*</p>
              <ul className="text-left text-xs font-bold text-gray-600 space-y-2 list-disc pl-4">
                <li>QR CODE का आप स्क्रीन शॉट लेके आप अपने किसी भी यूपीआई से स्कैन करके पेमेंट कर सकते हो।</li>
                <li>पेमेंट सफल होने के बाद "VERIFY PAYMENT" बटन पर क्लिक करें। बैलेंस आटोमेटिक आपके वॉलेट में जुड़ जायेगा।</li>
                <li>यह QR कोड केवल 2 मिनट के लिए वैध है।</li>
              </ul>
            </div>

            <button 
              onClick={verifyPayment}
              disabled={loading}
              className="w-full bg-primary text-white py-5 rounded-2xl font-black text-xl shadow-xl shadow-primary/30 active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" /> : null}
              <span>{loading ? 'VERIFYING...' : 'VERIFY PAYMENT ( पेमेंट चेक करें )'}</span>
            </button>

            <button 
              onClick={() => setStep('amount')}
              disabled={loading}
              className="w-full bg-gray-100 text-gray-500 py-4 rounded-xl font-bold active:scale-95 transition-all"
            >
              BACK
            </button>
          </motion.div>
        )}

        {step === 'withdraw' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-primary/10 border border-primary/20 p-6 rounded-3xl flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20">
                  <Wallet size={24} />
                </div>
                <div>
                  <p className="text-gray-500 text-sm font-bold uppercase tracking-widest">Available Balance</p>
                  <p className="text-3xl font-black text-dark">₹{user?.walletBalance || 0}</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-xl border border-gray-100 space-y-6">
              <div className="space-y-4">
                <label className="text-gray-500 font-black text-xs uppercase tracking-widest ml-2">Withdrawal Amount</label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-primary font-black text-xl">₹</div>
                  <input
                    type="number"
                    placeholder="Enter Amount (Min ₹500)"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl py-4 pl-10 pr-6 focus:outline-none focus:border-primary transition-all text-xl font-black"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-gray-500 font-black text-xs uppercase tracking-widest ml-2">UPI ID (PhonePe/GPay/Paytm)</label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-primary">
                    <CreditCard size={20} />
                  </div>
                  <input
                    type="text"
                    placeholder="example@okaxis"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl py-4 pl-12 pr-6 focus:outline-none focus:border-primary transition-all text-lg font-bold"
                  />
                </div>
              </div>

              <div className="bg-accent/10 p-4 rounded-2xl space-y-2">
                <p className="text-accent font-black text-xs uppercase tracking-widest flex items-center gap-2">
                  <AlertCircle size={14} />
                  Withdrawal Rules
                </p>
                <ul className="text-[10px] font-bold text-gray-600 space-y-1 list-disc pl-4">
                  <li>Minimum withdrawal amount is ₹500.</li>
                  <li>Withdrawal requests are processed within 2-4 hours.</li>
                  <li>Ensure your UPI ID is correct. We are not responsible for wrong transfers.</li>
                </ul>
              </div>

              <button 
                onClick={handleWithdrawRequest}
                disabled={loading || !amount || !upiId || Number(amount) < 500}
                className="w-full bg-header text-white py-5 rounded-2xl font-black text-xl shadow-xl shadow-header/30 active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="animate-spin" /> : null}
                <span>{loading ? 'PROCESSING...' : 'WITHDRAW NOW'}</span>
              </button>
            </div>
          </motion.div>
        )}

        {step === 'success' && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-10 rounded-3xl shadow-2xl border border-gray-100 flex flex-col items-center text-center space-y-6"
          >
            <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center">
              <CheckCircle2 size={64} />
            </div>
            <h3 className="text-2xl font-black text-dark uppercase tracking-widest">
              {isWithdrawMode ? 'WITHDRAWAL REQUESTED' : 'PAYMENT SUCCESSFUL'}
            </h3>
            <p className="text-gray-600 font-medium">
              {isWithdrawMode 
                ? 'आपका विड्रॉल रिक्वेस्ट सबमिट हो गया है। एडमिन द्वारा चेक करने के बाद 2-4 घंटे में पेमेंट कर दिया जाएगा।'
                : 'आपका पेमेंट सफल रहा! बैलेंस आपके वॉलेट में आटोमेटिक जोड़ दिया गया है।'}
            </p>
            <div className="bg-gray-50 p-4 rounded-2xl w-full">
              <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-1">Amount Added</p>
              <p className="text-3xl font-black text-primary">₹{amount}</p>
            </div>
            <button 
              onClick={() => navigate('/')}
              className="w-full bg-header text-white py-4 rounded-xl font-black text-lg shadow-xl shadow-header/30 active:scale-95 transition-all uppercase tracking-widest"
            >
              GO TO DASHBOARD
            </button>
          </motion.div>
        )}

        <div className="text-center pt-8 pb-12">
          <a 
            href={`https://wa.me/${settings?.whatsapp || '911234567890'}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-3 text-primary font-black text-lg hover:underline"
          >
            <MessageSquare size={24} />
            <span>Need Help? WhatsApp Us</span>
          </a>
        </div>
      </div>
    </Layout>
  );
}
