import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import JodiGrid from '../components/JodiGrid';
import { ArrowLeft, Clock, Play, Loader2, Trash2, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../hooks/useAuth';
import { firebaseService } from '../services/firebaseService';
import { Game } from '../types';

interface AddedBid {
  number: string;
  amount: number;
}

export default function PlayScreen() {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [game, setGame] = useState<Game | null>(null);
  const [activeTab, setActiveTab] = useState<'JODI' | 'CROSSING' | 'COPY_PASTE'>('JODI');
  
  // JODI Grid State
  const [gridBids, setGridBids] = useState<{ [num: string]: string }>({});
  
  // CROSSING State
  const [crossingDigits, setCrossingDigits] = useState('');
  const [crossingAmount, setCrossingAmount] = useState('');
  
  // COPY PASTE State
  const [copyPasteDigits, setCopyPasteDigits] = useState('');
  const [copyPasteAmount, setCopyPasteAmount] = useState('');
  const [withPalti, setWithPalti] = useState(false);
  
  // Common Added Bids List (for Crossing and Copy Paste)
  const [addedBids, setAddedBids] = useState<AddedBid[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = firebaseService.getGames((games) => {
      const foundGame = games.find(g => g.id === gameId);
      setGame(foundGame || null);
    });
    return () => unsubscribe();
  }, [gameId]);

  const handleAddCrossing = () => {
    if (!crossingDigits || !crossingAmount) return;
    const amount = parseInt(crossingAmount);
    if (isNaN(amount) || amount <= 0) return;

    const digits = crossingDigits.split('').filter(d => !isNaN(parseInt(d)));
    if (digits.length < 2) return;

    const newBids: AddedBid[] = [];
    for (let i = 0; i < digits.length; i++) {
      for (let j = 0; j < digits.length; j++) {
        newBids.push({
          number: digits[i] + digits[j],
          amount: amount
        });
      }
    }

    setAddedBids(prev => [...prev, ...newBids]);
    setCrossingDigits('');
    setCrossingAmount('');
  };

  const handleAddCopyPaste = () => {
    if (!copyPasteDigits || !copyPasteAmount) return;
    const amount = parseInt(copyPasteAmount);
    if (isNaN(amount) || amount <= 0) return;

    // Split digits into pairs of 2
    const pairs: string[] = [];
    for (let i = 0; i < copyPasteDigits.length; i += 2) {
      const pair = copyPasteDigits.substring(i, i + 2);
      if (pair.length === 2 && !isNaN(parseInt(pair))) {
        pairs.push(pair);
      }
    }

    if (pairs.length === 0) return;

    const newBids: AddedBid[] = [];
    pairs.forEach(p => {
      newBids.push({ number: p, amount });
      if (withPalti) {
        const palti = p.split('').reverse().join('');
        if (palti !== p) {
          newBids.push({ number: palti, amount });
        }
      }
    });

    setAddedBids(prev => [...prev, ...newBids]);
    setCopyPasteDigits('');
    setCopyPasteAmount('');
  };

  const removeBid = (index: number) => {
    setAddedBids(prev => prev.filter((_, i) => i !== index));
  };

  const handlePlay = async () => {
    if (!user || !game) return;
    
    // Combine Grid Bids and Added Bids
    const finalBids: AddedBid[] = [...addedBids];
    Object.entries(gridBids).forEach(([num, amt]) => {
      const amount = parseInt(amt as string);
      if (!isNaN(amount) && amount > 0) {
        finalBids.push({ number: num, amount });
      }
    });

    if (finalBids.length === 0) return;

    const totalAmount = finalBids.reduce((sum, b) => sum + b.amount, 0);

    if (user.walletBalance < totalAmount) {
      setError('Insufficient balance. Please add funds.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await firebaseService.placeBids(user!.uid, game!.id, game!.name, finalBids);
      navigate('/bid-history');
    } catch (err: any) {
      console.error('Error placing bid:', err);
      setError(err.message || 'Failed to place bid. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const gridTotal = Object.values(gridBids).reduce((sum: number, amt: string) => sum + (parseInt(amt) || 0), 0);
  const addedTotal = addedBids.reduce((sum: number, b: AddedBid) => sum + b.amount, 0);
  const totalAmount = gridTotal + addedTotal;

  if (!game) {
    return (
      <Layout userBalance={user?.walletBalance || 0}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Loader2 className="animate-spin mb-4" size={48} />
          <p className="font-bold uppercase tracking-widest">Loading Game...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      {/* Header */}
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">{game.name}</h2>
        </div>
        <div className="flex items-center gap-2 text-accent font-bold text-sm">
          <Clock size={16} />
          <span>{game.closeTime}</span>
        </div>
      </div>

      {/* Sub-header for Time */}
      <div className="bg-accent text-dark px-4 py-2 text-center text-xs font-black uppercase tracking-widest shadow-sm">
        मोटी जोड़ी लास्ट टाइम : {game.closeTime}
      </div>

      <div className="p-4 space-y-6 pb-32">
        {error && (
          <div className="bg-red-500/20 border border-red-500/50 text-red-500 p-3 rounded-xl text-sm font-bold text-center">
            {error}
          </div>
        )}

        {/* Tabs */}
        <div className="flex bg-white rounded-xl p-1 shadow-sm border border-gray-100">
          {(['JODI', 'CROSSING', 'COPY_PASTE'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 rounded-lg font-bold text-xs transition-all uppercase tracking-wider ${
                activeTab === tab 
                  ? 'bg-header text-white shadow-md' 
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              {tab.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {activeTab === 'JODI' && (
            <motion.div 
              key="jodi"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <JodiGrid 
                bids={gridBids} 
                onChange={(num, amt) => setGridBids(prev => ({ ...prev, [num]: amt }))} 
              />
            </motion.div>
          )}

          {activeTab === 'CROSSING' && (
            <motion.div 
              key="crossing"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
                <div className="space-y-4">
                  <div className="relative">
                    <label className="absolute -top-2 left-3 bg-white px-1 text-[10px] font-black text-header uppercase tracking-widest">Enter Digit</label>
                    <input
                      type="text"
                      value={crossingDigits}
                      onChange={(e) => setCrossingDigits(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 123"
                      className="w-full border-2 border-gray-200 rounded-xl px-4 py-4 font-bold text-dark focus:border-header focus:outline-none transition-colors"
                    />
                  </div>
                  <div className="relative">
                    <label className="absolute -top-2 left-3 bg-white px-1 text-[10px] font-black text-header uppercase tracking-widest">Enter Amount</label>
                    <input
                      type="number"
                      value={crossingAmount}
                      onChange={(e) => setCrossingAmount(e.target.value)}
                      placeholder="0"
                      className="w-full border-2 border-gray-200 rounded-xl px-4 py-4 font-bold text-dark focus:border-header focus:outline-none transition-colors"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddCrossing}
                  className="w-full bg-accent text-dark py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-accent/20 active:scale-95 transition-transform flex items-center justify-center gap-2"
                >
                  <Plus size={20} />
                  ADD
                </button>
              </div>
            </motion.div>
          )}

          {activeTab === 'COPY_PASTE' && (
            <motion.div 
              key="copy_paste"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
                <div className="space-y-4">
                  <div className="relative">
                    <label className="absolute -top-2 left-3 bg-white px-1 text-[10px] font-black text-header uppercase tracking-widest">Enter Digit</label>
                    <input
                      type="text"
                      value={copyPasteDigits}
                      onChange={(e) => setCopyPasteDigits(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="e.g. 010203"
                      className="w-full border-2 border-gray-200 rounded-xl px-4 py-4 font-bold text-dark focus:border-header focus:outline-none transition-colors"
                    />
                  </div>
                  <div className="relative">
                    <label className="absolute -top-2 left-3 bg-white px-1 text-[10px] font-black text-header uppercase tracking-widest">Enter Amount</label>
                    <input
                      type="number"
                      value={copyPasteAmount}
                      onChange={(e) => setCopyPasteAmount(e.target.value)}
                      placeholder="0"
                      className="w-full border-2 border-gray-200 rounded-xl px-4 py-4 font-bold text-dark focus:border-header focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setWithPalti(true)}
                    className={`py-4 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 border-2 ${
                      withPalti ? 'bg-header text-white border-header shadow-lg' : 'bg-white text-gray-500 border-gray-100'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${withPalti ? 'border-white' : 'border-gray-300'}`}>
                      {withPalti && <div className="w-2 h-2 bg-white rounded-full" />}
                    </div>
                    WITH PALTI
                  </button>
                  <button
                    onClick={() => setWithPalti(false)}
                    className={`py-4 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-2 border-2 ${
                      !withPalti ? 'bg-header text-white border-header shadow-lg' : 'bg-white text-gray-500 border-gray-100'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${!withPalti ? 'border-white' : 'border-gray-300'}`}>
                      {!withPalti && <div className="w-2 h-2 bg-white rounded-full" />}
                    </div>
                    WITHOUT PALTI
                  </button>
                </div>

                <button
                  onClick={handleAddCopyPaste}
                  className="w-full bg-accent text-dark py-4 rounded-xl font-black uppercase tracking-widest shadow-lg shadow-accent/20 active:scale-95 transition-transform flex items-center justify-center gap-2"
                >
                  <Plus size={20} />
                  ADD
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Added Bids Table (for Crossing and Copy Paste) */}
        {(activeTab === 'CROSSING' || activeTab === 'COPY_PASTE') && addedBids.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
          >
            <table className="w-full text-sm">
              <thead className="bg-header text-white">
                <tr>
                  <th className="py-3 px-4 text-left font-black uppercase tracking-widest text-[10px]">Number</th>
                  <th className="py-3 px-4 text-left font-black uppercase tracking-widest text-[10px]">Amount</th>
                  <th className="py-3 px-4 text-right font-black uppercase tracking-widest text-[10px]">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {addedBids.map((bid, index) => (
                  <tr key={index} className="bg-header/5">
                    <td className="py-3 px-4 font-black text-header">{bid.number}</td>
                    <td className="py-3 px-4 font-bold text-dark">₹{bid.amount}</td>
                    <td className="py-3 px-4 text-right">
                      <button 
                        onClick={() => removeBid(index)}
                        className="bg-red-500 text-white p-2 rounded-lg active:scale-90 transition-transform shadow-md shadow-red-500/20"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        )}
      </div>

      {/* Footer Play Bar */}
      <div className="fixed bottom-[60px] left-0 right-0 bg-white border-t border-gray-100 px-4 py-3 flex items-center justify-between z-30 shadow-[0_-4px_15px_rgba(0,0,0,0.05)]">
        <div className="flex items-baseline gap-2">
          <span className="text-gray-500 font-bold text-xl">₹</span>
          <span className="text-3xl font-black text-dark">{totalAmount}</span>
        </div>
        <button 
          onClick={handlePlay}
          disabled={totalAmount === 0 || loading}
          className={`flex items-center gap-2 px-10 py-3 rounded-xl font-black text-lg transition-all shadow-xl ${
            totalAmount > 0 && !loading
              ? 'bg-header text-white shadow-header/30 active:scale-95' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          {loading ? <Loader2 className="animate-spin" size={20} /> : <Play size={20} fill="currentColor" />}
          <span>{loading ? 'WAIT...' : 'PLAY'}</span>
        </button>
      </div>
    </Layout>
  );
}
