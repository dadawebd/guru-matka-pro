import React, { useState } from 'react';
import { Phone, Lock, MessageSquare, User as UserIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { SUPPORT_WHATSAPP } from '../constants';
import { firebaseService } from '../services/firebaseService';

export default function Login() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [mpin, setMpin] = useState('');
  const [confirmMpin, setConfirmMpin] = useState('');
  const [name, setName] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length === 10 && mpin.length >= 4) {
      setLoading(true);
      setError(null);
      try {
        const user = await firebaseService.loginWithMpin(phoneNumber, mpin);
        if (user) {
          navigate('/');
        }
      } catch (err: any) {
        console.error('Error logging in:', err);
        setError(err.message || 'Invalid Mobile Number or Password');
      } finally {
        setLoading(false);
      }
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length !== 10) {
      setError('Enter valid 10-digit mobile number');
      return;
    }
    if (mpin.length < 4) {
      setError('Password must be at least 4 digits');
      return;
    }
    if (mpin !== confirmMpin) {
      setError('Passwords do not match');
      return;
    }
    if (!name.trim()) {
      setError('Enter your name');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const uid = await firebaseService.registerWithMpin(phoneNumber, name, mpin);
      if (uid) {
        navigate('/');
      }
    } catch (err: any) {
      console.error('Error registering:', err);
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#008080] flex flex-col items-center p-8 text-white font-sans">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-md flex flex-col items-center mt-12"
      >
        {/* Logo */}
        <div className="w-48 h-48 mb-6 relative">
          <img 
            src="https://picsum.photos/seed/king/400/400" 
            alt="Satta King Logo" 
            className="w-full h-full object-contain rounded-full border-4 border-yellow-500/30 shadow-2xl"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             {/* Overlay text if needed, but the image has it in the logo. Since I'm using a placeholder, I'll add a stylized text overlay */}
             <div className="bg-black/40 backdrop-blur-[1px] px-3 py-1 rounded-lg border border-white/20">
               <span className="text-xl font-black text-yellow-400 tracking-tighter uppercase">SATTA KING</span>
             </div>
          </div>
        </div>

        <h1 className="text-5xl font-black text-white mb-12 tracking-wider uppercase text-center">
          SATTA KING
        </h1>

        {error && (
          <div className="w-full p-4 bg-red-500/20 border border-red-500/50 rounded-xl mb-6 text-sm font-bold text-center text-red-200">
            {error}
          </div>
        )}

        <div className="w-full space-y-8">
          {mode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-8">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Mobile Number</label>
                <input
                  type="tel"
                  placeholder="Enter mobile number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Password</label>
                <input
                  type="password"
                  placeholder="Enter password"
                  value={mpin}
                  onChange={(e) => setMpin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              
              <button 
                type="submit" 
                disabled={loading || phoneNumber.length !== 10 || mpin.length < 4}
                className="w-full bg-[#ff6347] hover:bg-[#ff4500] text-white py-4 rounded-full text-xl font-bold uppercase tracking-widest shadow-lg active:scale-[0.98] transition-all disabled:opacity-50 mt-4"
              >
                {loading ? 'PLEASE WAIT...' : 'LOGIN'}
              </button>

              <div className="flex flex-col items-center gap-4 mt-8">
                <button 
                  type="button"
                  className="text-[#00ffff] font-medium text-lg hover:underline"
                >
                  Forgot Password?
                </button>
                <p className="text-white/80 text-lg">
                  Don't have an account? {' '}
                  <button 
                    type="button"
                    onClick={() => { setMode('register'); setError(null); }}
                    className="text-[#00ffff] font-bold hover:underline"
                  >
                    Register Now
                  </button>
                </p>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Full Name</label>
                <input
                  type="text"
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Mobile Number</label>
                <input
                  type="tel"
                  placeholder="Enter mobile number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Create Password</label>
                <input
                  type="password"
                  placeholder="Enter password"
                  value={mpin}
                  onChange={(e) => setMpin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white/70 block ml-1">Confirm Password</label>
                <input
                  type="password"
                  placeholder="Re-enter password"
                  value={confirmMpin}
                  onChange={(e) => setConfirmMpin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full bg-transparent border-b-2 border-white/30 py-3 px-1 focus:outline-none focus:border-white transition-all text-lg placeholder:text-white/30"
                  required
                  disabled={loading}
                />
              </div>
              
              <button 
                type="submit" 
                disabled={loading || phoneNumber.length !== 10 || mpin.length < 4 || mpin !== confirmMpin || !name}
                className="w-full bg-[#ff6347] hover:bg-[#ff4500] text-white py-4 rounded-full text-xl font-bold uppercase tracking-widest shadow-lg active:scale-[0.98] transition-all disabled:opacity-50 mt-4"
              >
                {loading ? 'PLEASE WAIT...' : 'REGISTER'}
              </button>

              <div className="flex flex-col items-center gap-4 mt-8">
                <p className="text-white/80 text-lg">
                  Already have an account? {' '}
                  <button 
                    type="button"
                    onClick={() => { setMode('login'); setError(null); }}
                    className="text-[#00ffff] font-bold hover:underline"
                  >
                    Login Now
                  </button>
                </p>
              </div>
            </form>
          )}
        </div>

        {/* Admin Quick Login (Hidden but useful for dev) */}
        <div className="mt-12 opacity-20 hover:opacity-100 transition-opacity">
          <button 
            onClick={() => {
              setPhoneNumber('9999999999');
              setMpin('123456');
              setMode('login');
            }}
            className="text-[10px] uppercase tracking-widest border border-white/20 px-4 py-1 rounded-full"
          >
            Admin Access
          </button>
        </div>
      </motion.div>
    </div>
  );
}
