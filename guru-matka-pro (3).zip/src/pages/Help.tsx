import React from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, MessageSquare, Phone, Mail, HelpCircle, ShieldCheck, FileText, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../hooks/useAuth';

export default function HelpScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const faqs = [
    {
      q: "How to add funds?",
      a: "Go to the Wallet section, enter the amount (minimum ₹100), and pay using the QR code or available payment gateways. After payment, click 'I HAVE PAID' if using manual mode."
    },
    {
      q: "How long does it take to add funds?",
      a: "Automated gateway payments are instant. Manual payments take 10-15 minutes for verification by the admin."
    },
    {
      q: "What is the minimum withdrawal?",
      a: "The minimum withdrawal amount is ₹500. Requests are processed within 2-4 hours."
    },
    {
      q: "How to play?",
      a: "Select a game from the dashboard, choose your bid type (Jodi, Andar, or Bahar), enter your numbers and amount, and click 'Place Bid'."
    }
  ];

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">Help & Support</h2>
        </div>
      </div>

      <div className="p-4 space-y-6 pb-24">
        {/* Contact Cards */}
        <div className="grid grid-cols-2 gap-4">
          <a 
            href="https://wa.me/911234567890" 
            target="_blank" 
            rel="noreferrer"
            className="bg-white p-6 rounded-3xl shadow-lg border border-gray-100 flex flex-col items-center text-center space-y-3 active:scale-95 transition-all"
          >
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center">
              <MessageSquare size={24} />
            </div>
            <span className="text-xs font-black uppercase tracking-widest text-dark">WhatsApp</span>
          </a>
          <a 
            href="tel:+911234567890"
            className="bg-white p-6 rounded-3xl shadow-lg border border-gray-100 flex flex-col items-center text-center space-y-3 active:scale-95 transition-all"
          >
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
              <Phone size={24} />
            </div>
            <span className="text-xs font-black uppercase tracking-widest text-dark">Call Us</span>
          </a>
        </div>

        {/* FAQs */}
        <div className="space-y-4">
          <h3 className="text-sm font-black text-dark uppercase tracking-widest flex items-center gap-2 ml-2">
            <HelpCircle size={16} className="text-primary" />
            Frequently Asked Questions
          </h3>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 space-y-2"
              >
                <p className="text-sm font-black text-dark">{faq.q}</p>
                <p className="text-xs font-bold text-gray-500 leading-relaxed">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Legal Links */}
        <div className="space-y-3">
          <button className="w-full bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-3">
              <ShieldCheck size={20} className="text-primary" />
              <span className="text-sm font-bold text-dark">Privacy Policy</span>
            </div>
            <ArrowLeft size={16} className="rotate-180 text-gray-300 group-hover:text-primary transition-colors" />
          </button>
          <button className="w-full bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-3">
              <FileText size={20} className="text-primary" />
              <span className="text-sm font-bold text-dark">Terms & Conditions</span>
            </div>
            <ArrowLeft size={16} className="rotate-180 text-gray-300 group-hover:text-primary transition-colors" />
          </button>
          <button className="w-full bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between group active:scale-[0.98] transition-all">
            <div className="flex items-center gap-3">
              <Info size={20} className="text-primary" />
              <span className="text-sm font-bold text-dark">About Us</span>
            </div>
            <ArrowLeft size={16} className="rotate-180 text-gray-300 group-hover:text-primary transition-colors" />
          </button>
        </div>

        <div className="text-center space-y-2 pt-4">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Version 2.0.4</p>
          <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">© 2026 GURU MATKA OFFICIAL</p>
        </div>
      </div>
    </Layout>
  );
}
