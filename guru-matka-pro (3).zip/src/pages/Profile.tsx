import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, User, Phone, Wallet, Calendar, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../hooks/useAuth';
import { auth } from '../firebase';

export default function ProfileScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const formatDate = (timestamp: any) => {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center gap-3 sticky top-[52px] z-30 shadow-md">
        <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
          <ArrowLeft size={24} />
        </button>
        <h2 className="text-lg font-bold uppercase tracking-widest">User Profile</h2>
      </div>

      <div className="p-4 space-y-6 max-w-md mx-auto">
        {/* Profile Header Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100 flex flex-col items-center text-center relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-2 bg-primary"></div>
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4 border-4 border-white shadow-lg">
            <User size={48} className="text-primary" />
          </div>
          <h3 className="text-2xl font-black text-dark uppercase tracking-tight">{user?.name || 'Guru Matka User'}</h3>
          <p className="text-gray-500 font-bold tracking-widest text-sm">{user?.phoneNumber}</p>
          
          <div className="mt-6 flex items-center gap-2 bg-green-50 text-green-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">
            <ShieldCheck size={14} />
            Verified Account
          </div>
        </motion.div>

        {/* Details List */}
        <div className="space-y-3">
          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                <Wallet size={20} />
              </div>
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Wallet Balance</p>
                <p className="text-lg font-black text-dark">₹{user?.walletBalance || 0}</p>
              </div>
            </div>
            <button 
              onClick={() => navigate('/add-fund')}
              className="bg-primary text-white px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest shadow-lg shadow-primary/20 active:scale-95 transition-all"
            >
              Add
            </button>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center">
              <Phone size={20} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Mobile Number</p>
              <p className="text-lg font-black text-dark">{user?.phoneNumber}</p>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
            <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center">
              <Calendar size={20} />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Member Since</p>
              <p className="text-lg font-black text-dark">{formatDate(user?.createdAt)}</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 pt-4">
          <button 
            onClick={() => navigate('/wallet-history')}
            className="bg-gray-50 text-gray-600 py-4 rounded-2xl font-black text-xs uppercase tracking-widest border border-gray-200 active:scale-95 transition-all"
          >
            Passbook
          </button>
          <button 
            onClick={() => navigate('/bid-history')}
            className="bg-gray-50 text-gray-600 py-4 rounded-2xl font-black text-xs uppercase tracking-widest border border-gray-200 active:scale-95 transition-all"
          >
            Play History
          </button>
        </div>
      </div>
    </Layout>
  );
}
