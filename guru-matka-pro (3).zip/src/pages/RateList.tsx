import React from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, Star, TrendingUp, Award } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../hooks/useAuth';

export default function RateListScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const rates = [
    { title: 'JODI RATE', rate: '10 का 950', icon: <Star className="text-yellow-500" /> },
    { title: 'HARUF RATE', rate: '10 का 95', icon: <Award className="text-orange-500" /> },
    { title: 'SINGLE RATE', rate: '10 का 95', icon: <TrendingUp className="text-green-500" /> },
  ];

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center gap-3 sticky top-[52px] z-30 shadow-md">
        <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
          <ArrowLeft size={24} />
        </button>
        <h2 className="text-lg font-bold uppercase tracking-widest">Rate List</h2>
      </div>

      <div className="p-4 space-y-6 max-w-md mx-auto">
        <div className="bg-red-600 text-white py-3 px-4 rounded-xl text-center font-black text-lg tracking-widest shadow-lg shadow-red-600/20 uppercase">
          हमारी गेम रेट लिस्ट
        </div>

        <div className="space-y-4">
          {rates.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-3xl p-6 shadow-xl border border-gray-100 flex items-center justify-between relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-2 h-full bg-primary"></div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center shadow-inner">
                  {item.icon}
                </div>
                <div>
                  <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest">{item.title}</h3>
                  <p className="text-2xl font-black text-dark tracking-tighter">{item.rate}</p>
                </div>
              </div>
              <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                Best Rate
              </div>
            </motion.div>
          ))}
        </div>

        <div className="bg-indigo-900 rounded-3xl p-8 text-white text-center shadow-2xl relative overflow-hidden border border-white/10">
          <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-white/5 rounded-full blur-2xl"></div>
          <p className="text-base font-bold mb-2 leading-tight opacity-80 italic">"मार्केट में सबसे ज्यादा रेट केवल गुरु मटका पर"</p>
          <p className="text-accent font-black text-2xl tracking-widest uppercase">फास्ट पेमेंट - फुल रेट</p>
        </div>
      </div>
    </Layout>
  );
}
