import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { collection, query, orderBy, onSnapshot, where, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Game } from '../types';
import { useAuth } from '../hooks/useAuth';
import { Loader2, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ResultRecord {
  id: string;
  gameId: string;
  gameName: string;
  result: string;
  date: string;
  timestamp: any;
}

export default function MonthlyChart() {
  const now = new Date();
  const [games, setGames] = useState<Game[]>([]);
  const [results, setResults] = useState<ResultRecord[]>([]);
  const [loading, setLoading] = useState(true);
  
  // States for the dropdowns
  const [tempMonth, setTempMonth] = useState(now.getMonth());
  const [tempYear, setTempYear] = useState(now.getFullYear());
  
  // States that actually trigger the data fetch
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth());
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const unsubGames = onSnapshot(query(collection(db, 'games'), orderBy('openTime', 'asc')), (snap) => {
      setGames(snap.docs.map(d => ({ id: d.id, ...d.data() } as Game)));
    });

    return () => unsubGames();
  }, []);

  useEffect(() => {
    setLoading(true);
    const startOfMonth = new Date(selectedYear, selectedMonth, 1);
    const endOfMonth = new Date(selectedYear, selectedMonth + 1, 0, 23, 59, 59);
    
    const startTimestamp = Timestamp.fromDate(startOfMonth);
    const endTimestamp = Timestamp.fromDate(endOfMonth);

    const unsubResults = onSnapshot(
      query(
        collection(db, 'results_history'), 
        where('timestamp', '>=', startTimestamp),
        where('timestamp', '<=', endTimestamp),
        orderBy('timestamp', 'desc')
      ), 
      (snap) => {
        setResults(snap.docs.map(d => ({ id: d.id, ...d.data() } as ResultRecord)));
        setLoading(false);
      }
    );

    return () => unsubResults();
  }, [selectedMonth, selectedYear]);

  const handleSubmit = () => {
    setSelectedMonth(tempMonth);
    setSelectedYear(tempYear);
  };

  const getDaysInMonth = () => {
    return new Date(selectedYear, selectedMonth + 1, 0).getDate();
  };

  const formatDate = (day: number) => {
    const d = String(day).padStart(2, '0');
    const m = String(selectedMonth + 1).padStart(2, '0');
    const y = selectedYear;
    return `${d}-${m}-${y}`;
  };

  const getResultForGameAndDate = (gameId: string, dateStr: string) => {
    const [d, m, y] = dateStr.split('-');
    const normalizedDate = `${y}-${m}-${d}`;
    const record = results.find(r => r.gameId === gameId && r.date === normalizedDate);
    return record ? record.result : '';
  };

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const years = Array.from({ length: 5 }, (_, i) => now.getFullYear() - i);

  const days = Array.from({ length: getDaysInMonth() }, (_, i) => i + 1);

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="p-2 md:p-4 w-full">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate(-1)}
              className="p-2 bg-white rounded-full shadow-md active:scale-95 transition-transform"
            >
              <ArrowLeft size={20} />
            </button>
            <h2 className="text-xl font-black text-dark uppercase tracking-widest">Monthly Record Chart</h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 bg-white p-2 rounded-xl shadow-sm border border-gray-100">
            <select 
              value={tempMonth}
              onChange={(e) => setTempMonth(Number(e.target.value))}
              className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs font-bold uppercase outline-none focus:ring-2 focus:ring-primary/20"
            >
              {months.map((month, i) => (
                <option key={month} value={i}>{month}</option>
              ))}
            </select>
            <select 
              value={tempYear}
              onChange={(e) => setTempYear(Number(e.target.value))}
              className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs font-bold uppercase outline-none focus:ring-2 focus:ring-primary/20"
            >
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
            <button 
              onClick={handleSubmit}
              className="px-6 py-2 bg-primary text-white text-[10px] font-black rounded-lg uppercase tracking-widest hover:opacity-90 active:scale-95 transition-all"
            >
              SUBMIT
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-2xl overflow-hidden border-2 border-black">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse table-auto">
              <thead>
                <tr>
                  <th className="bg-[#006400] text-white p-3 border border-black font-black text-sm uppercase tracking-wider sticky left-0 z-10 min-w-[100px]">
                    Date
                  </th>
                  {games.map(game => (
                    <th key={game.id} className="bg-[#006400] text-white p-3 border border-black font-black text-xs uppercase tracking-wider whitespace-nowrap px-6">
                      {game.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={games.length + 1} className="p-20 text-center bg-[#f5e6c8]">
                      <Loader2 className="animate-spin text-primary mx-auto" size={40} />
                      <p className="mt-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Loading Records...</p>
                    </td>
                  </tr>
                ) : (
                  days.map(day => {
                    const dateStr = formatDate(day);
                    return (
                      <tr key={day}>
                        <td className="bg-[#006400] text-white p-2 border border-black font-black text-xs text-center sticky left-0 z-10">
                          {dateStr}
                        </td>
                        {games.map(game => {
                          const result = getResultForGameAndDate(game.id, dateStr);
                          return (
                            <td key={game.id} className="bg-[#f5e6c8] p-2 border border-black font-black text-xl text-center text-black min-w-[120px]">
                              {result || ''}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 text-center text-gray-400 text-[10px] font-bold uppercase tracking-widest">
          © {new Date().getFullYear()} Guru Matka - Official Result Chart
        </div>
      </div>
    </Layout>
  );
}
