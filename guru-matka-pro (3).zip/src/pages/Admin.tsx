import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Users, Gamepad2, Trophy, Wallet, Bell, Settings, ArrowLeft, Search, Check, X, Loader2, History, Copy, MessageCircle, TrendingUp, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy, doc, updateDoc, setDoc, Timestamp, increment, getDoc, addDoc, deleteDoc } from 'firebase/firestore';
import { Game, User, Transaction, Bid, GlobalSettings } from '../types';

export default function AdminDashboard() {
  const { isAdmin: authIsAdmin, user: authUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'USERS' | 'GAMES' | 'BETS' | 'RESULTS' | 'WALLETS' | 'NOTIFICATIONS' | 'SETTINGS'>('DASHBOARD');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const [games, setGames] = useState<Game[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [bids, setBids] = useState<Bid[]>([]);
  const [banners, setBanners] = useState<any[]>([]);
  const [resultsHistory, setResultsHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Add Game State
  const [newGame, setNewGame] = useState({ name: '', openTime: '', closeTime: '' });
  const [addingGame, setAddingGame] = useState(false);

  const getLocalDate = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Result Declaration State
  const [selectedGameId, setSelectedGameId] = useState('');
  const [resultNumber, setResultNumber] = useState('');
  const [resultDate, setResultDate] = useState(getLocalDate());
  const [declaring, setDeclaring] = useState(false);

  // Notification State
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [isPush, setIsPush] = useState(false);
  const [sendingNotif, setSendingNotif] = useState(false);

  // Settings State
  const [settings, setSettings] = useState<GlobalSettings>({ 
    qrCode: '', 
    whatsapp: '', 
    upiId: '',
    jodiRate: 90,
    harufRate: 9,
    paymentMode: 'MANUAL',
    activeGateways: [],
    razorpayKey: '',
    razorpaySecret: '',
    cashfreeAppId: '',
    cashfreeSecret: '',
    upiGatewayMerchantId: '',
    upiGatewayKey: ''
  });
  const [savingSettings, setSavingSettings] = useState(false);

  // Cutting State
  const [jodiCutting, setJodiCutting] = useState('');
  const [harufCutting, setHarufCutting] = useState('');
  const [cuttingJodi, setCuttingJodi] = useState('');
  const [cuttingJodiAmount, setCuttingJodiAmount] = useState('');

  // Bets Filter State
  const [betsFilterGameId, setBetsFilterGameId] = useState('');
  const [betsFilterDate, setBetsFilterDate] = useState(getLocalDate());

  const formatTo12Hour = (time: string) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    let h = parseInt(hours);
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    h = h ? h : 12; // the hour '0' should be '12'
    return `${h}:${minutes} ${ampm}`;
  };

  useEffect(() => {
    const unsubGames = onSnapshot(query(collection(db, 'games'), orderBy('openTime', 'asc')), (snap) => {
      setGames(snap.docs.map(d => ({ id: d.id, ...d.data() } as Game)));
    }, (err) => {
      console.error('Games snapshot error:', err);
      setError(`Games: ${err.message}`);
    });

    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      setUsers(snap.docs.map(d => ({ uid: d.id, ...d.data() } as User)));
    }, (err) => {
      console.error('Users snapshot error:', err);
      setError(`Users: ${err.message}`);
    });

    const unsubTrans = onSnapshot(query(collection(db, 'transactions'), orderBy('timestamp', 'desc')), (snap) => {
      setTransactions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Transaction)));
    }, (err) => {
      console.error('Transactions snapshot error:', err);
      setError(`Transactions: ${err.message}`);
    });

    const unsubBids = onSnapshot(query(collection(db, 'bids'), orderBy('timestamp', 'desc')), (snap) => {
      setBids(snap.docs.map(d => ({ id: d.id, ...d.data() } as Bid)));
    }, (err) => {
      console.error('Bids snapshot error:', err);
      setError(`Bids: ${err.message}`);
    });

    const unsubSettings = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) setSettings(snap.data() as any);
    }, (err) => {
      console.error('Settings snapshot error:', err);
      setError(`Settings: ${err.message}`);
    });

    const unsubBanners = onSnapshot(collection(db, 'banners'), (snap) => {
      setBanners(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    const unsubResults = onSnapshot(query(collection(db, 'results_history'), orderBy('timestamp', 'desc')), (snap) => {
      setResultsHistory(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    setLoading(false);
    return () => {
      unsubGames();
      unsubUsers();
      unsubTrans();
      unsubBids();
      unsubSettings();
      unsubBanners();
      unsubResults();
    };
  }, []);

  const handleFixAdminRole = async () => {
    if (!authUser?.uid) return;
    try {
      await updateDoc(doc(db, 'users', authUser.uid), { role: 'admin' });
      alert('Admin role fixed! Please refresh the page.');
    } catch (err) {
      console.error('Error fixing admin role:', err);
      alert('Failed to fix role. This might be due to permission rules. Please check firestore.rules.');
    }
  };

  const handleAddGame = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGame.name || !newGame.openTime || !newGame.closeTime) return;
    setAddingGame(true);
    try {
      const gameId = newGame.name.toLowerCase().replace(/\s+/g, '-');
      await setDoc(doc(db, 'games', gameId), {
        id: gameId,
        name: newGame.name,
        openTime: newGame.openTime,
        closeTime: newGame.closeTime,
        status: 'PLAY',
        oldResult: '00',
        newResult: '00'
      });
      setNewGame({ name: '', openTime: '', closeTime: '' });
      alert('Game added successfully!');
    } catch (err) {
      console.error('Error adding game:', err);
    } finally {
      setAddingGame(false);
    }
  };

  const handleApproveTransaction = async (transId: string, userId: string, amount: number, type: string) => {
    try {
      await updateDoc(doc(db, 'transactions', transId), { status: 'APPROVED' });
      if (type === 'DEPOSIT') {
        await updateDoc(doc(db, 'users', userId), { walletBalance: increment(amount) });
      }
      // For WITHDRAW, balance was already deducted on request
      alert('Transaction approved!');
    } catch (err) {
      console.error('Error approving transaction:', err);
    }
  };

  const handleRejectTransaction = async (transId: string, userId: string, amount: number, type: string) => {
    try {
      await updateDoc(doc(db, 'transactions', transId), { status: 'REJECTED' });
      if (type === 'WITHDRAW') {
        // Refund if withdrawal is rejected
        await updateDoc(doc(db, 'users', userId), { walletBalance: increment(amount) });
      }
      alert('Transaction rejected!');
    } catch (err) {
      console.error('Error rejecting transaction:', err);
    }
  };

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifMessage) return;
    setSendingNotif(true);
    try {
      // Add to in-app notifications
      await addDoc(collection(db, 'notifications'), {
        title: notifTitle,
        message: notifMessage,
        timestamp: Timestamp.now()
      });

      // If push is enabled, add to push_triggers for Cloud Function to handle
      if (isPush) {
        await addDoc(collection(db, 'push_triggers'), {
          title: notifTitle,
          message: notifMessage,
          timestamp: Timestamp.now(),
          status: 'PENDING'
        });
      }

      setNotifTitle('');
      setNotifMessage('');
      setIsPush(false);
      alert('Notification sent!');
    } catch (err) {
      console.error('Error sending notification:', err);
    } finally {
      setSendingNotif(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await setDoc(doc(db, 'settings', 'global'), settings);
      alert('Settings saved!');
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setSavingSettings(false);
    }
  };

  const handleManageBalance = async (userId: string, currentBalance: number) => {
    const amountStr = prompt(`Current Balance: ₹${currentBalance}\nEnter amount to ADD (use negative for SUBTRACT):`, '0');
    if (amountStr === null) return;
    const amount = Number(amountStr);
    if (isNaN(amount) || amount === 0) return;

    try {
      await updateDoc(doc(db, 'users', userId), {
        walletBalance: increment(amount)
      });
      // Log as a transaction
      await addDoc(collection(db, 'transactions'), {
        userId,
        amount: Math.abs(amount),
        type: 'BONUS',
        status: 'COMPLETED',
        description: amount > 0 ? 'Admin Credit' : 'Admin Debit',
        timestamp: Timestamp.now()
      });
      alert('Balance updated successfully!');
    } catch (err) {
      console.error('Error managing balance:', err);
      alert('Failed to update balance');
    }
  };

  const handleDeclareResult = async () => {
    if (!selectedGameId || !resultNumber || !resultDate) return;
    if (resultNumber.length > 2) {
      alert('Result must be 1 or 2 digits');
      return;
    }
    setDeclaring(true);
    try {
      const game = games.find(g => g.id === selectedGameId);
      if (!game) return;

      // Update game result
      await updateDoc(doc(db, 'games', selectedGameId), {
        oldResult: game.newResult,
        newResult: resultNumber,
        status: 'TIME OUT',
        lastResultDate: resultDate
      });

      // Also save to a results history collection
      await addDoc(collection(db, 'results_history'), {
        gameId: selectedGameId,
        gameName: game.name,
        result: resultNumber,
        date: resultDate,
        timestamp: Timestamp.now()
      });

      // Process winners (simplified logic)
      const pendingBids = bids.filter(b => b.gameId === selectedGameId && b.status === 'PENDING');
      for (const bid of pendingBids) {
        const isWin = bid.numbers.includes(resultNumber);
        const status = isWin ? 'WIN' : 'LOSS';
        
        if (isWin) {
          const rate = (bid.type === 'JODI' || bid.type === 'CROSSING') ? (settings.jodiRate || 90) : (settings.harufRate || 9);
          const winAmount = bid.amount * rate;
          await updateDoc(doc(db, 'bids', bid.id), { 
            status: 'WIN',
            winAmount: winAmount
          });
          await updateDoc(doc(db, 'users', bid.userId), { walletBalance: increment(winAmount) });
          await addDoc(collection(db, 'transactions'), {
            userId: bid.userId,
            amount: winAmount,
            type: 'WIN',
            status: 'COMPLETED',
            description: `Win on ${game.name} (${bid.type})`,
            timestamp: Timestamp.now()
          });
        } else {
          await updateDoc(doc(db, 'bids', bid.id), { status: 'LOSS' });
        }
      }

      setResultNumber('');
      alert('Result declared and winners processed!');
    } catch (err) {
      console.error('Error declaring result:', err);
    } finally {
      setDeclaring(false);
    }
  };

  const sidebarItems = [
    { id: 'DASHBOARD', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'USERS', icon: Users, label: 'Users' },
    { id: 'GAMES', icon: Gamepad2, label: 'Games' },
    { id: 'BETS', icon: History, label: 'Bett Report' },
    { id: 'RESULTS', icon: Trophy, label: 'Results' },
    { id: 'BANNERS', icon: Bell, label: 'Banners' },
    { id: 'WALLETS', icon: Wallet, label: 'Wallets' },
    { id: 'NOTIFICATIONS', icon: Bell, label: 'Notifications' },
    { id: 'SETTINGS', icon: Settings, label: 'Settings' },
  ];

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-dark text-white"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-dark text-white p-4 flex items-center justify-between sticky top-0 z-[60] shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center text-white font-black">G</div>
          <h1 className="font-black text-lg tracking-widest uppercase">ADMIN</h1>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2">
          {isMobileMenuOpen ? <X size={24} /> : <div className="space-y-1.5">
            <div className="w-6 h-0.5 bg-white"></div>
            <div className="w-6 h-0.5 bg-white"></div>
            <div className="w-6 h-0.5 bg-white"></div>
          </div>}
        </button>
      </div>

      {/* Admin Sidebar */}
      <aside className={`${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 fixed md:sticky top-0 left-0 w-64 bg-dark text-white flex flex-col h-screen shadow-2xl z-50`}>
        <div className="hidden md:flex p-6 border-b border-white/10 items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xl">G</div>
          <h1 className="font-black text-xl tracking-widest uppercase">ADMIN PANEL</h1>
        </div>

        <nav className="flex-1 py-6 overflow-y-auto">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as any);
                setIsMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-4 px-6 py-4 transition-all ${
                activeTab === item.id 
                  ? 'bg-primary text-white border-r-4 border-accent shadow-lg shadow-primary/20' 
                  : 'text-white/50 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon size={20} />
              <span className="font-bold uppercase tracking-widest text-xs">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/10">
          <button 
            onClick={() => navigate('/')}
            className="w-full flex items-center justify-center gap-2 bg-red-500/20 text-red-500 py-3 rounded-xl font-bold hover:bg-red-500/30 transition-all"
          >
            <ArrowLeft size={18} />
            <span>EXIT ADMIN</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">
        <header className="hidden md:flex bg-white border-b border-gray-200 px-8 py-6 items-center justify-between sticky top-0 z-40">
          <h2 className="text-2xl font-black text-dark uppercase tracking-widest">{activeTab}</h2>
          <div className="flex items-center gap-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search anything..." 
                className="bg-gray-100 border-none rounded-full py-2 pl-10 pr-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-medium"
              />
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-black text-dark">Admin User</p>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Super Admin</p>
                {!authUser?.role || authUser.role !== 'admin' ? (
                  <button 
                    onClick={handleFixAdminRole}
                    className="text-[10px] text-red-500 underline font-bold"
                  >
                    Fix Admin Role
                  </button>
                ) : null}
              </div>
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-500">
                <Users size={20} />
              </div>
            </div>
          </div>
        </header>

        <div className="p-4 md:p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-sm font-bold">
              ⚠️ {error}
            </div>
          )}
          <AnimatePresence mode="wait">
            {activeTab === 'DASHBOARD' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                  <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Users</p>
                    <p className="text-2xl md:text-3xl font-black text-dark">{users.length}</p>
                    <div className="h-1 w-12 rounded-full bg-blue-500"></div>
                  </div>
                  <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Active Games</p>
                    <p className="text-2xl md:text-3xl font-black text-dark">{games.filter(g => g.status === 'PLAY').length}</p>
                    <div className="h-1 w-12 rounded-full bg-green-500"></div>
                  </div>
                  <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Bids</p>
                    <p className="text-2xl md:text-3xl font-black text-dark">{bids.length}</p>
                    <div className="h-1 w-12 rounded-full bg-purple-500"></div>
                  </div>
                  <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Pending Deposits</p>
                    <p className="text-2xl md:text-3xl font-black text-dark">{transactions.filter(t => t.status === 'PENDING' && t.type === 'DEPOSIT').length}</p>
                    <div className="h-1 w-12 rounded-full bg-red-500"></div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-black text-dark uppercase tracking-widest">Recent Bids</h3>
                    </div>
                    <div className="space-y-4">
                      {bids.slice(0, 5).map((bid) => (
                        <div key={bid.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xs uppercase">G</div>
                            <div>
                              <p className="text-xs font-black text-dark uppercase">{bid.gameName} - {bid.type}</p>
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">User ID: {bid.userId?.slice(0, 8)}...</p>
                            </div>
                          </div>
                          <p className="font-black text-dark">₹{bid.amount}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-black text-dark uppercase tracking-widest">Pending Deposits</h3>
                    </div>
                    <div className="space-y-4">
                      {transactions.filter(t => t.status === 'PENDING' && t.type === 'DEPOSIT').slice(0, 5).map((trans) => (
                        <div key={trans.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-red-100 text-red-600 rounded-lg flex items-center justify-center font-bold text-xs uppercase">D</div>
                            <div>
                              <p className="text-xs font-black text-dark uppercase">Deposit Request</p>
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">User: {trans.userId?.slice(0, 8)}...</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <p className="font-black text-dark">₹{trans.amount}</p>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => handleApproveTransaction(trans.id, trans.userId, trans.amount, trans.type)}
                                className="p-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all active:scale-90"
                              >
                                <Check size={14} />
                              </button>
                              <button 
                                onClick={() => handleRejectTransaction(trans.id, trans.userId, trans.amount, trans.type)}
                                className="p-1.5 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all active:scale-90"
                              >
                                <X size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'RESULTS' && (
              <motion.div 
                key="results"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 space-y-8"
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-black text-dark uppercase tracking-widest">Declare Game Result</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Game</label>
                    <select 
                      value={selectedGameId}
                      onChange={(e) => setSelectedGameId(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold uppercase tracking-widest"
                    >
                      <option value="">Choose Game</option>
                      {games.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Date</label>
                    <input 
                      type="date" 
                      value={resultDate}
                      onChange={(e) => setResultDate(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Result Number (00-99)</label>
                    <input 
                      type="number" 
                      placeholder="45" 
                      value={resultNumber}
                      onChange={(e) => setResultNumber(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-xl font-black text-center"
                    />
                  </div>
                  <div className="flex items-end">
                    <button 
                      onClick={handleDeclareResult}
                      disabled={declaring || !selectedGameId || !resultNumber}
                      className="w-full bg-primary text-white py-4 rounded-xl font-black text-lg shadow-xl shadow-primary/20 hover:opacity-90 active:scale-95 transition-all uppercase tracking-widest disabled:opacity-50"
                    >
                      {declaring ? 'PROCESSING...' : 'DECLARE RESULT'}
                    </button>
                  </div>
                </div>

                <div className="pt-8 border-t border-gray-100">
                  <h4 className="font-black text-dark uppercase tracking-widest mb-6">Result History</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Date</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Game</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Result</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {resultsHistory.map((res) => (
                          <tr key={res.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4 font-bold text-dark text-xs">{res.date}</td>
                            <td className="px-6 py-4 font-bold text-dark uppercase">{res.gameName}</td>
                            <td className="px-6 py-4 font-black text-primary text-lg">{res.result}</td>
                            <td className="px-6 py-4 flex gap-2">
                              <button 
                                onClick={async () => {
                                  const newRes = prompt('Enter new result:', res.result);
                                  if (newRes !== null && newRes !== res.result) {
                                    await updateDoc(doc(db, 'results_history', res.id), { result: newRes });
                                    // If it's the latest result for this game, update the game doc too
                                    const game = games.find(g => g.id === res.gameId);
                                    if (game && game.lastResultDate === res.date) {
                                      await updateDoc(doc(db, 'games', res.gameId), { newResult: newRes });
                                    }
                                  }
                                }}
                                className="text-xs font-bold text-primary hover:underline"
                              >
                                Edit
                              </button>
                                <button 
                                  onClick={async () => {
                                    if (confirm('Delete this result record? This will REVERSE all wins for this result. Are you sure?')) {
                                      const { deleteDoc, writeBatch, getDocs, query, where, collection } = await import('firebase/firestore');
                                      
                                      // Query Firestore directly for the bids to ensure we have the latest winAmount
                                      const bidsQuery = query(
                                        collection(db, 'bids'),
                                        where('gameId', '==', res.gameId),
                                        where('status', 'in', ['WIN', 'LOSS'])
                                      );
                                      
                                      const bidsSnapshot = await getDocs(bidsQuery);
                                      const affectedBids = bidsSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Bid)).filter(b => {
                                        const date = b.timestamp?.toDate?.() ? b.timestamp.toDate() : (b.timestamp?.seconds ? new Date(b.timestamp.seconds * 1000) : null);
                                        if (!date) return false;
                                        const year = date.getFullYear();
                                        const month = String(date.getMonth() + 1).padStart(2, '0');
                                        const day = String(date.getDate()).padStart(2, '0');
                                        const bidDate = `${year}-${month}-${day}`;
                                        return bidDate === res.date;
                                      });

                                      const batch = writeBatch(db);
                                      let reversedCount = 0;
                                      
                                      for (const bid of affectedBids) {
                                        if (bid.status === 'WIN' && bid.winAmount) {
                                          // Deduct win amount from user wallet
                                          batch.update(doc(db, 'users', bid.userId), { 
                                            walletBalance: increment(-bid.winAmount) 
                                          });
                                          // Add reversal transaction
                                          batch.set(doc(collection(db, 'transactions')), {
                                            userId: bid.userId,
                                            amount: bid.winAmount,
                                            type: 'BID', 
                                            status: 'COMPLETED',
                                            description: `Win Reversed: ${res.gameName} (${res.date})`,
                                            timestamp: Timestamp.now()
                                          });
                                        }
                                        // Reset bid status to PENDING
                                        batch.update(doc(db, 'bids', bid.id), { 
                                          status: 'PENDING',
                                          winAmount: null 
                                        });
                                        reversedCount++;
                                      }

                                      await batch.commit();
                                      
                                      // Also clear the result from the Game document itself
                                      await updateDoc(doc(db, 'games', res.gameId), {
                                        newResult: '00',
                                        lastResultDate: ''
                                      });

                                      await deleteDoc(doc(db, 'results_history', res.id));
                                      alert(`Result deleted and ${reversedCount} bids reversed to PENDING.`);
                                    }
                                  }}
                                  className="text-xs font-bold text-red-500 hover:underline"
                                >
                                  Delete
                                </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'USERS' && (
              <motion.div 
                key="users"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
              >
                <div className="max-h-[600px] overflow-y-auto overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-gray-50 border-b border-gray-100 sticky top-0 z-10">
                      <tr>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Phone Number</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Wallet Balance</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Role</th>
                        <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((user) => (
                        <tr key={user.uid} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 font-bold text-dark">{user.phoneNumber}</td>
                          <td className="px-6 py-4 font-black text-primary">₹{user.walletBalance}</td>
                          <td className="px-6 py-4">
                            <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-widest ${
                              user.role === 'admin' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'
                            }`}>
                              {user.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 flex gap-3">
                            <button 
                              onClick={() => handleManageBalance(user.uid, user.walletBalance)}
                              className="text-primary font-bold text-xs hover:underline"
                            >
                              Manage Balance
                            </button>
                            <button 
                              onClick={async () => {
                                if (confirm(`Are you sure you want to delete user ${user.phoneNumber}? This will only delete their Firestore profile.`)) {
                                  await deleteDoc(doc(db, 'users', user.uid));
                                  alert('User profile deleted.');
                                }
                              }}
                              className="text-red-500 font-bold text-xs hover:underline"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === 'BETS' && (
              <motion.div 
                key="bets"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6 max-w-4xl mx-auto"
              >
                {/* Header Section */}
                <div className="bg-header p-6 rounded-t-[32px] flex items-center justify-between shadow-lg">
                  <div className="flex items-center gap-4">
                    <button onClick={() => setActiveTab('DASHBOARD')} className="p-2 bg-white/10 rounded-full text-white active:scale-90 transition-all">
                      <ArrowLeft size={20} />
                    </button>
                    <h3 className="text-xl font-black text-white uppercase tracking-tighter italic">BETT REPORT</h3>
                  </div>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => {
                        const filteredGames = betsFilterGameId 
                          ? games.filter(g => g.id === betsFilterGameId)
                          : games;
                        
                        let fullText = '';
                        let hasData = false;
                        
                        filteredGames.forEach(game => {
                          const gameBids = bids.filter(b => {
                            const date = b.timestamp?.toDate?.() ? b.timestamp.toDate() : (b.timestamp?.seconds ? new Date(b.timestamp.seconds * 1000) : null);
                            if (!date) return false;
                            const year = date.getFullYear();
                            const month = String(date.getMonth() + 1).padStart(2, '0');
                            const day = String(date.getDate()).padStart(2, '0');
                            const bidDate = `${year}-${month}-${day}`;
                            return b.gameId === game.id && bidDate === betsFilterDate && b.status === 'PENDING';
                          });
                          if (gameBids.length === 0) return;
                          
                          const jodiMap: Record<string, number> = {};
                          const andarMap: Record<string, number> = {};
                          const baharMap: Record<string, number> = {};
                          const cutPercent = parseInt(jodiCutting) || 0;
                          const specJodi = cuttingJodi.trim();
                          const specJodiAmt = parseInt(cuttingJodiAmount) || 0;
                          
                          gameBids.forEach(b => {
                            if (b.type === 'JODI' || b.type === 'CROSSING') {
                              b.numbers.forEach(num => { jodiMap[num] = (jodiMap[num] || 0) + b.amount; });
                            } else if (b.type === 'ANDAR') {
                              b.numbers.forEach(num => { andarMap[num] = (andarMap[num] || 0) + b.amount; });
                            } else if (b.type === 'BAHAR') {
                              b.numbers.forEach(num => { baharMap[num] = (baharMap[num] || 0) + b.amount; });
                            }
                          });
                          
                          Object.keys(jodiMap).forEach(num => {
                            let amt = jodiMap[num];
                            if (cutPercent > 0) amt = Math.floor(amt * (1 - cutPercent / 100));
                            if (specJodi && num === specJodi) amt -= specJodiAmt;
                            if (amt > 0) jodiMap[num] = amt; else delete jodiMap[num];
                          });
                          Object.keys(andarMap).forEach(num => {
                            let amt = andarMap[num];
                            if (cutPercent > 0) amt = Math.floor(amt * (1 - cutPercent / 100));
                            if (amt > 0) andarMap[num] = amt; else delete andarMap[num];
                          });
                          Object.keys(baharMap).forEach(num => {
                            let amt = baharMap[num];
                            if (cutPercent > 0) amt = Math.floor(amt * (1 - cutPercent / 100));
                            if (amt > 0) baharMap[num] = amt; else delete baharMap[num];
                          });
                          
                          if (Object.keys(jodiMap).length === 0 && Object.keys(andarMap).length === 0 && Object.keys(baharMap).length === 0) return;
                          
                          hasData = true;
                          const [y, m, d] = betsFilterDate.split('-');
                          const formattedDate = `${d}-${m}-${y}`;
                          
                          let gameTotal = 0;
                          const jodiEntries = Object.entries(jodiMap).map(([num, amt]) => { gameTotal += amt; return `${num}(${amt})`; }).join(' ');
                          const andarEntries = Object.entries(andarMap).map(([num, amt]) => { gameTotal += amt; return `${num}(${amt})`; }).join(' ');
                          const baharEntries = Object.entries(baharMap).map(([num, amt]) => { gameTotal += amt; return `${num}(${amt})`; }).join(' ');
                          
                          fullText += `Game ${game.name}  Date ${formattedDate}\n`;
                          fullText += `______________________________________\n`;
                          fullText += `${jodiEntries}\n`;
                          fullText += `______________________________________\n`;
                          fullText += `Haruf Andar Bahar\n`;
                          fullText += `A ${andarEntries}\n`;
                          fullText += `B ${baharEntries}\n`;
                          fullText += `______________________________________\n`;
                          fullText += `All Total Game Amount ${gameTotal}\n\n`;
                        });
                        if (!hasData) { alert('No data to copy.'); return; }
                        navigator.clipboard.writeText(fullText);
                        alert('Report copied!');
                      }}
                      className="p-2 bg-white/10 rounded-lg text-white active:scale-95 transition-all"
                    >
                      <Copy size={20} />
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-full text-xs font-black uppercase tracking-widest active:scale-95 transition-all">
                      <MessageCircle size={14} />
                      WHATSAPP
                    </button>
                  </div>
                </div>

                {/* Total Box */}
                <div className="bg-header/90 p-8 flex items-center justify-between text-white border-t border-white/10">
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-white/50 uppercase tracking-[0.2em]">ALL GAMES</p>
                    <p className="text-4xl font-black tracking-tighter">
                      ₹{games.reduce((acc, game) => {
                        const gameBids = bids.filter(b => {
                          const date = b.timestamp?.toDate?.() ? b.timestamp.toDate() : (b.timestamp?.seconds ? new Date(b.timestamp.seconds * 1000) : null);
                          if (!date) return false;
                          const year = date.getFullYear();
                          const month = String(date.getMonth() + 1).padStart(2, '0');
                          const day = String(date.getDate()).padStart(2, '0');
                          const bidDate = `${year}-${month}-${day}`;
                          return b.gameId === game.id && b.status === 'PENDING' && bidDate === betsFilterDate;
                        });
                        const cutPercent = parseInt(jodiCutting) || 0;
                        const specJodi = cuttingJodi.trim();
                        const specJodiAmt = parseInt(cuttingJodiAmount) || 0;
                        let gameTotal = 0;
                        const jodiMap: Record<string, number> = {};
                        gameBids.forEach(b => b.numbers.forEach(num => { jodiMap[num] = (jodiMap[num] || 0) + b.amount; }));
                        Object.keys(jodiMap).forEach(num => {
                          let amt = jodiMap[num];
                          if (cutPercent > 0) amt = Math.floor(amt * (1 - cutPercent / 100));
                          if (specJodi && num === specJodi) amt -= specJodiAmt;
                          if (amt > 0) gameTotal += amt;
                        });
                        return acc + gameTotal;
                      }, 0)}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center">
                    <TrendingUp size={24} className="text-yellow-400" />
                  </div>
                </div>

                {/* Filter & Cutting Section */}
                <div className="bg-gray-100 p-6 space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">-- All Games --</label>
                    <select 
                      value={betsFilterGameId}
                      onChange={(e) => setBetsFilterGameId(e.target.value)}
                      className="w-full bg-white border-none rounded-xl py-4 px-4 text-sm font-bold text-header uppercase tracking-widest shadow-sm"
                    >
                      <option value="">-- All Games --</option>
                      {games.map(g => (
                        <option key={g.id} value={g.id}>{g.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-header/20 p-4 rounded-3xl border-2 border-orange-500/30 flex flex-col items-center gap-2">
                      <p className="text-[8px] font-black text-red-400 uppercase tracking-widest">FLAT CUT (₹)</p>
                      <input 
                        type="number" 
                        value={jodiCutting}
                        onChange={(e) => setJodiCutting(e.target.value)}
                        className="bg-transparent border-none text-center text-2xl font-black text-header w-full focus:ring-0"
                        placeholder="0"
                      />
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">AUTO APPLIED</p>
                    </div>
                    <div className="bg-header/20 p-4 rounded-3xl border-2 border-red-500/30 flex flex-col items-center gap-2">
                      <p className="text-[8px] font-black text-red-400 uppercase tracking-widest">SINGLE JODI CUT</p>
                      <div className="flex items-center gap-2">
                        <input 
                          type="text" 
                          value={cuttingJodi}
                          onChange={(e) => setCuttingJodi(e.target.value)}
                          className="w-12 bg-transparent border-none text-center text-xl font-black text-header focus:ring-0"
                          placeholder="No"
                        />
                        <span className="text-header/30">|</span>
                        <input 
                          type="number" 
                          value={cuttingJodiAmount}
                          onChange={(e) => setCuttingJodiAmount(e.target.value)}
                          className="w-16 bg-transparent border-none text-center text-xl font-black text-header focus:ring-0"
                          placeholder="₹"
                        />
                      </div>
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest">LIVE UPDATE</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Select Date</label>
                    <input 
                      type="date" 
                      value={betsFilterDate}
                      onChange={(e) => setBetsFilterDate(e.target.value)}
                      className="w-full bg-white border-none rounded-xl py-4 px-4 text-sm font-bold text-header shadow-sm"
                    />
                  </div>
                </div>

                {/* Report List */}
                <div className="bg-gray-200 p-4 rounded-b-[32px] space-y-3">
                  {games
                    .filter(g => !betsFilterGameId || g.id === betsFilterGameId)
                    .map((game) => {
                    const gameBids = bids.filter(b => {
                      const date = b.timestamp?.toDate?.() ? b.timestamp.toDate() : (b.timestamp?.seconds ? new Date(b.timestamp.seconds * 1000) : null);
                      if (!date) return false;
                      const year = date.getFullYear();
                      const month = String(date.getMonth() + 1).padStart(2, '0');
                      const day = String(date.getDate()).padStart(2, '0');
                      const bidDate = `${year}-${month}-${day}`;
                      return b.gameId === game.id && b.status === 'PENDING' && bidDate === betsFilterDate;
                    });
                    
                    const cutPercent = parseInt(jodiCutting) || 0;
                    const specJodi = cuttingJodi.trim();
                    const specJodiAmt = parseInt(cuttingJodiAmount) || 0;

                    const combinedBids: { num: string, amt: number, type: string }[] = [];
                    const jodiMap: Record<string, number> = {};
                    const andarMap: Record<string, number> = {};
                    const baharMap: Record<string, number> = {};

                    gameBids.forEach(b => {
                      if (b.type === 'JODI' || b.type === 'CROSSING') {
                        b.numbers.forEach(num => { jodiMap[num] = (jodiMap[num] || 0) + b.amount; });
                      } else if (b.type === 'ANDAR') {
                        b.numbers.forEach(num => { andarMap[num] = (andarMap[num] || 0) + b.amount; });
                      } else if (b.type === 'BAHAR') {
                        b.numbers.forEach(num => { baharMap[num] = (baharMap[num] || 0) + b.amount; });
                      }
                    });

                    Object.entries(jodiMap).forEach(([num, amt]) => {
                      let finalAmt = amt;
                      if (cutPercent > 0) finalAmt = Math.floor(finalAmt * (1 - cutPercent / 100));
                      if (specJodi && num === specJodi) finalAmt -= specJodiAmt;
                      if (finalAmt > 0) combinedBids.push({ num, amt: finalAmt, type: 'JODI' });
                    });
                    Object.entries(andarMap).forEach(([num, amt]) => {
                      let finalAmt = amt;
                      if (cutPercent > 0) finalAmt = Math.floor(finalAmt * (1 - cutPercent / 100));
                      if (finalAmt > 0) combinedBids.push({ num, amt: finalAmt, type: 'ANDAR' });
                    });
                    Object.entries(baharMap).forEach(([num, amt]) => {
                      let finalAmt = amt;
                      if (cutPercent > 0) finalAmt = Math.floor(finalAmt * (1 - cutPercent / 100));
                      if (finalAmt > 0) combinedBids.push({ num, amt: finalAmt, type: 'BAHAR' });
                    });

                    if (combinedBids.length === 0) return null;

                    return (
                      <div key={game.id} className="space-y-3">
                        <div className="flex items-center justify-between px-2">
                          <h4 className="text-xs font-black text-header uppercase tracking-widest">{game.name} REPORT</h4>
                          <span className="text-[10px] font-bold text-gray-400">{betsFilterDate}</span>
                        </div>
                        {combinedBids.map((bid, idx) => (
                          <div key={idx} className="bg-header/10 p-3 rounded-2xl flex items-center justify-between border border-white/5 shadow-sm">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg font-black ${
                                bid.amt >= 2000 ? 'bg-yellow-400 text-header' : 'bg-header text-white'
                              }`}>
                                {bid.num}
                              </div>
                              <div>
                                <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">{bid.type}</p>
                                <p className="text-sm font-black text-header tracking-tight">₹{bid.amt}</p>
                              </div>
                            </div>
                            <div className="w-6 h-6 rounded-full bg-header/5 flex items-center justify-center text-header/20">
                              <CheckCircle2 size={14} />
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {activeTab === 'GAMES' && (
              <motion.div 
                key="games"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-black text-dark uppercase tracking-widest mb-6">Add New Game</h3>
                  <form onSubmit={handleAddGame} className="grid grid-cols-4 gap-6 items-end">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Game Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. GALI" 
                        value={newGame.name}
                        onChange={(e) => setNewGame({ ...newGame, name: e.target.value })}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold uppercase"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Open Time</label>
                      <input 
                        type="time" 
                        value={newGame.openTime}
                        onChange={(e) => setNewGame({ ...newGame, openTime: e.target.value })}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Close Time</label>
                      <input 
                        type="time" 
                        value={newGame.closeTime}
                        onChange={(e) => setNewGame({ ...newGame, closeTime: e.target.value })}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                      />
                    </div>
                    <button 
                      type="submit"
                      disabled={addingGame}
                      className="bg-primary text-white py-3 rounded-xl font-black shadow-lg shadow-primary/20 hover:opacity-90 active:scale-95 transition-all uppercase tracking-widest text-sm"
                    >
                      {addingGame ? 'ADDING...' : 'ADD GAME'}
                    </button>
                  </form>
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-x-auto">
                  <div className="min-w-[800px]">
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Game Name</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Open Time</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Close Time</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {games.map((game) => (
                          <tr key={game.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4 font-bold text-dark uppercase">{game.name}</td>
                            <td className="px-6 py-4 font-bold text-gray-500">{formatTo12Hour(game.openTime)}</td>
                            <td className="px-6 py-4 font-bold text-gray-500">{formatTo12Hour(game.closeTime)}</td>
                            <td className="px-6 py-4">
                              <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-widest ${
                                game.status === 'PLAY' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                              }`}>
                                {game.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 flex gap-2">
                              <button 
                                onClick={async () => {
                                  if (confirm(`Reset result for ${game.name}? This will set it to 00.`)) {
                                    await updateDoc(doc(db, 'games', game.id), {
                                      newResult: '00',
                                      lastResultDate: ''
                                    });
                                    alert('Result reset successfully.');
                                  }
                                }}
                                className="text-xs font-bold text-orange-500 hover:underline"
                              >
                                Reset Result
                              </button>
                              <button 
                                onClick={async () => {
                                  const newStatus = game.status === 'PLAY' ? 'TIME OUT' : 'PLAY';
                                  await updateDoc(doc(db, 'games', game.id), { status: newStatus });
                                }}
                                className="text-xs font-bold text-primary hover:underline"
                              >
                                Toggle Status
                              </button>
                              <button 
                                onClick={async () => {
                                  if (confirm(`Delete ${game.name}?`)) {
                                    const { deleteDoc } = await import('firebase/firestore');
                                    await deleteDoc(doc(db, 'games', game.id));
                                  }
                                }}
                                className="text-xs font-bold text-red-500 hover:underline"
                              >
                                Delete
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'BANNERS' && (
              <motion.div 
                key="banners"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-black text-dark uppercase tracking-widest mb-6">Upload Slider Banner</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Image File</label>
                      <input 
                        type="file" 
                        accept="image/*"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          
                          const reader = new FileReader();
                          reader.onload = async (event) => {
                            const base64 = event.target?.result as string;
                            if (base64.length > 1000000) {
                              alert('Image is too large. Please select a smaller image (under 1MB).');
                              return;
                            }
                            
                            await addDoc(collection(db, 'banners'), {
                              imageUrl: base64,
                              timestamp: Timestamp.now()
                            });
                            alert('Banner uploaded successfully!');
                          };
                          reader.readAsDataURL(file);
                        }}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                      />
                    </div>
                    <p className="text-[10px] font-bold text-gray-400 italic">* Max size 1MB. Recommended aspect ratio 16:9.</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  {banners.map((banner) => (
                    <div key={banner.id} className="relative group rounded-2xl overflow-hidden shadow-lg border border-gray-100">
                      <img src={banner.imageUrl} alt="Banner" className="w-full h-32 object-cover" referrerPolicy="no-referrer" />
                      <button 
                        onClick={async () => {
                          if (confirm('Delete this banner?')) {
                            const { deleteDoc } = await import('firebase/firestore');
                            await deleteDoc(doc(db, 'banners', banner.id));
                          }
                        }}
                        className="absolute top-2 right-2 p-2 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'WALLETS' && (
              <motion.div 
                key="wallets"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-x-auto">
                  <div className="min-w-[800px]">
                    <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                      <h3 className="font-black text-dark uppercase tracking-widest">Pending Requests</h3>
                    </div>
                    <table className="w-full text-left border-collapse">
                      <thead className="bg-gray-50 border-b border-gray-100">
                        <tr>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Type</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">User ID</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Amount</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Details</th>
                          <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.filter(t => t.status === 'PENDING').map((tx) => (
                          <tr key={tx.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4">
                              <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-widest ${
                                tx.type === 'DEPOSIT' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                              }`}>
                                {tx.type}
                              </span>
                            </td>
                            <td className="px-6 py-4 font-bold text-dark text-xs">{tx.userId}</td>
                            <td className="px-6 py-4 font-black text-dark">₹{tx.amount}</td>
                            <td className="px-6 py-4 text-xs font-bold text-gray-500">{tx.description}</td>
                            <td className="px-6 py-4 flex gap-2">
                              <button 
                                onClick={() => handleApproveTransaction(tx.id, tx.userId, tx.amount, tx.type)}
                                className="p-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all"
                              >
                                <Check size={16} />
                              </button>
                              <button 
                                onClick={() => handleRejectTransaction(tx.id, tx.userId, tx.amount, tx.type)}
                                className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all"
                              >
                                <X size={16} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'NOTIFICATIONS' && (
              <motion.div 
                key="notifications"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100"
              >
                <h3 className="font-black text-dark uppercase tracking-widest mb-6">Send New Notification</h3>
                <form onSubmit={handleSendNotification} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Title</label>
                    <input 
                      type="text" 
                      placeholder="e.g. New Game Added!" 
                      value={notifTitle}
                      onChange={(e) => setNotifTitle(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold uppercase"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Message</label>
                    <textarea 
                      rows={4}
                      placeholder="Enter notification message..." 
                      value={notifMessage}
                      onChange={(e) => setNotifMessage(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      id="isPush"
                      checked={isPush}
                      onChange={(e) => setIsPush(e.target.checked)}
                      className="w-4 h-4 text-primary focus:ring-primary border-gray-300 rounded"
                    />
                    <label htmlFor="isPush" className="text-xs font-bold text-gray-600 uppercase tracking-widest cursor-pointer">
                      Send as Push Notification (Mobile Status Bar)
                    </label>
                  </div>
                  <button 
                    type="submit"
                    disabled={sendingNotif}
                    className="w-full bg-primary text-white py-4 rounded-xl font-black shadow-xl shadow-primary/20 hover:opacity-90 active:scale-95 transition-all uppercase tracking-widest"
                  >
                    {sendingNotif ? 'SENDING...' : 'SEND NOTIFICATION'}
                  </button>
                </form>
              </motion.div>
            )}

            {activeTab === 'SETTINGS' && (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="font-black text-dark uppercase tracking-widest mb-6">Global Settings</h3>
                  <form onSubmit={handleSaveSettings} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">QR Code URL (Manual)</label>
                        <input 
                          type="text" 
                          placeholder="https://..." 
                          value={settings.qrCode}
                          onChange={(e) => setSettings({ ...settings, qrCode: e.target.value })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">WhatsApp Number</label>
                        <input 
                          type="text" 
                          placeholder="+91..." 
                          value={settings.whatsapp}
                          onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Admin UPI ID (Manual)</label>
                        <input 
                          type="text" 
                          placeholder="upi@bank" 
                          value={settings.upiId}
                          onChange={(e) => setSettings({ ...settings, upiId: e.target.value })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Payment Mode</label>
                        <select 
                          value={settings.paymentMode}
                          onChange={(e) => setSettings({ ...settings, paymentMode: e.target.value as any })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        >
                          <option value="MANUAL">MANUAL ONLY</option>
                          <option value="GATEWAY">GATEWAY ONLY</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Jodi Rate (e.g. 90)</label>
                        <input 
                          type="number" 
                          value={settings.jodiRate}
                          onChange={(e) => setSettings({ ...settings, jodiRate: Number(e.target.value) })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Haruf Rate (e.g. 9)</label>
                        <input 
                          type="number" 
                          value={settings.harufRate}
                          onChange={(e) => setSettings({ ...settings, harufRate: Number(e.target.value) })}
                          className="w-full bg-gray-50 border border-gray-200 rounded-xl py-4 px-4 focus:ring-2 focus:ring-primary/20 transition-all text-sm font-bold"
                        />
                      </div>
                    </div>

                    <div className="pt-6 border-t border-gray-100">
                      <h4 className="font-black text-dark uppercase tracking-widest mb-4">Payment Gateways</h4>
                      <div className="space-y-6">
                        {/* Razorpay */}
                        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs uppercase tracking-widest">Razorpay</span>
                            <input 
                              type="checkbox" 
                              checked={settings.activeGateways?.includes('RAZORPAY')}
                              onChange={(e) => {
                                const active = settings.activeGateways || [];
                                if (e.target.checked) setSettings({ ...settings, activeGateways: [...active, 'RAZORPAY'] });
                                else setSettings({ ...settings, activeGateways: active.filter(g => g !== 'RAZORPAY') });
                              }}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <input 
                              type="text" 
                              placeholder="Key ID"
                              value={settings.razorpayKey}
                              onChange={(e) => setSettings({ ...settings, razorpayKey: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                            <input 
                              type="text" 
                              placeholder="Key Secret"
                              value={settings.razorpaySecret}
                              onChange={(e) => setSettings({ ...settings, razorpaySecret: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                          </div>
                        </div>

                        {/* Cashfree */}
                        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs uppercase tracking-widest">Cashfree</span>
                            <input 
                              type="checkbox" 
                              checked={settings.activeGateways?.includes('CASHFREE')}
                              onChange={(e) => {
                                const active = settings.activeGateways || [];
                                if (e.target.checked) setSettings({ ...settings, activeGateways: [...active, 'CASHFREE'] });
                                else setSettings({ ...settings, activeGateways: active.filter(g => g !== 'CASHFREE') });
                              }}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <input 
                              type="text" 
                              placeholder="App ID"
                              value={settings.cashfreeAppId}
                              onChange={(e) => setSettings({ ...settings, cashfreeAppId: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                            <input 
                              type="text" 
                              placeholder="Secret Key"
                              value={settings.cashfreeSecret}
                              onChange={(e) => setSettings({ ...settings, cashfreeSecret: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                          </div>
                        </div>

                        {/* UPI Gateway */}
                        <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs uppercase tracking-widest">UPI Gateway</span>
                            <input 
                              type="checkbox" 
                              checked={settings.activeGateways?.includes('UPIGATEWAY')}
                              onChange={(e) => {
                                const active = settings.activeGateways || [];
                                if (e.target.checked) setSettings({ ...settings, activeGateways: [...active, 'UPIGATEWAY'] });
                                else setSettings({ ...settings, activeGateways: active.filter(g => g !== 'UPIGATEWAY') });
                              }}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <input 
                              type="text" 
                              placeholder="Merchant ID"
                              value={settings.upiGatewayMerchantId}
                              onChange={(e) => setSettings({ ...settings, upiGatewayMerchantId: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                            <input 
                              type="text" 
                              placeholder="API Key"
                              value={settings.upiGatewayKey}
                              onChange={(e) => setSettings({ ...settings, upiGatewayKey: e.target.value })}
                              className="w-full bg-white border border-gray-200 rounded-xl py-2 px-4 text-xs font-bold"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={savingSettings}
                      className="w-full bg-primary text-white py-4 rounded-xl font-black shadow-xl shadow-primary/20 hover:opacity-90 active:scale-95 transition-all uppercase tracking-widest"
                    >
                      {savingSettings ? 'SAVING...' : 'SAVE SETTINGS'}
                    </button>
                  </form>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
