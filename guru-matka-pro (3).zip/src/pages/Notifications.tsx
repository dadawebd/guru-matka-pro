import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, Bell, Clock, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { firebaseService } from '../services/firebaseService';
import { useAuth } from '../hooks/useAuth';
import { Notification } from '../types';

export default function Notifications() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = firebaseService.getNotifications((fetched) => {
      setNotifications(fetched);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">Notifications</h2>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-bold uppercase tracking-widest">Loading Notifications...</p>
          </div>
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400 space-y-4">
            <Bell size={64} className="opacity-20" />
            <p className="font-bold text-lg italic uppercase tracking-widest">No notifications</p>
          </div>
        ) : (
          notifications.map((notif, index) => (
            <motion.div
              key={notif.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex gap-4"
            >
              <div className="w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center shrink-0">
                <Bell size={24} />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <h4 className="font-black text-dark uppercase tracking-tight">{notif.title}</h4>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    <Clock size={10} />
                    <span>{notif.timestamp?.toDate?.()?.toLocaleTimeString() || 'Recent'}</span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 font-medium leading-relaxed">{notif.message}</p>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </Layout>
  );
}
