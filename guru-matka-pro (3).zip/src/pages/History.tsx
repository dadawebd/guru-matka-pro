import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ArrowLeft, History, TrendingUp, Loader2 } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { firebaseService } from '../services/firebaseService';
import { useAuth } from '../hooks/useAuth';
import { Bid } from '../types';

export default function HistoryScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const isWinHistory = location.pathname.includes('win');
  
  const [bids, setBids] = useState<Bid[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const unsubscribe = firebaseService.getBids(user.uid, (fetchedBids) => {
      setBids(fetchedBids);
      setLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  const filteredBids = isWinHistory ? bids.filter(b => b.status === 'WIN') : bids;

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-[52px] z-30 shadow-md">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1 active:scale-95 transition-transform">
            <ArrowLeft size={24} />
          </button>
          <h2 className="text-lg font-bold uppercase tracking-widest">
            {isWinHistory ? 'Win History' : 'Bid History'}
          </h2>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-bold uppercase tracking-widest">Loading History...</p>
          </div>
        ) : filteredBids.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400 space-y-4">
            <History size={64} className="opacity-20" />
            <p className="font-bold text-lg italic uppercase tracking-widest">No history found</p>
          </div>
        ) : (
          filteredBids.map((bid, index) => (
            <motion.div
              key={bid.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden flex flex-col"
            >
              <div className="p-5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                    bid.status === 'WIN' ? 'bg-green-50 text-green-600' : 
                    bid.status === 'LOSS' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                  }`}>
                    <TrendingUp size={32} />
                  </div>
                  <div>
                    <h3 className="font-black text-xl text-dark uppercase tracking-tight">{bid.gameName}</h3>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">
                      {bid.timestamp?.toDate?.()?.toLocaleString() || 'Recent'}
                    </p>
                  </div>
                </div>
                <div className="text-right flex flex-col items-end gap-2">
                  <p className={`text-2xl font-black ${bid.status === 'WIN' ? 'text-green-600' : 'text-dark'}`}>
                    ₹{bid.status === 'WIN' ? (bid.winAmount || bid.amount) : bid.amount}
                  </p>
                  <span className={`text-[11px] font-black px-4 py-1 rounded-lg uppercase tracking-widest ${
                    bid.status === 'WIN' ? 'bg-green-600 text-white shadow-lg shadow-green-600/20' : 
                    bid.status === 'LOSS' ? 'bg-red-600 text-white shadow-lg shadow-red-600/20' : 'bg-blue-500 text-white shadow-lg shadow-blue-500/20'
                  }`}>
                    {bid.status}
                  </span>
                </div>
              </div>
              <div className="bg-gray-50/50 px-6 py-3 flex justify-between items-center text-xs font-black text-gray-500 uppercase tracking-[0.2em] border-t border-gray-100">
                <span>TYPE: {bid.type}</span>
                <span>NUMBERS: {bid.numbers.join(', ')}</span>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </Layout>
  );
}
