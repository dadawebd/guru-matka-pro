import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import GameCard from '../components/GameCard';
import BannerSlider from '../components/BannerSlider';
import { Game, Banner } from '../types';
import { SUPPORT_WHATSAPP } from '../constants';
import { motion } from 'motion/react';
import { PlusCircle, Wallet, PlayCircle, MessageSquare, RefreshCcw, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { firebaseService } from '../services/firebaseService';
import { useAuth } from '../hooks/useAuth';

export default function Dashboard() {
  const [games, setGames] = useState<Game[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBtn, setShowInstallBtn] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const unsubGames = firebaseService.getGames((fetchedGames) => {
      setGames(fetchedGames);
    });
    const unsubBanners = firebaseService.getBanners((fetchedBanners) => {
      setBanners(fetchedBanners);
    });

    // PWA Install Prompt logic
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBtn(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      unsubGames();
      unsubBanners();
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBtn(false);
    }
    setDeferredPrompt(null);
  };

  return (
    <Layout userBalance={user?.walletBalance || 0}>
      <div className="p-3 space-y-4 max-w-md mx-auto">
        {/* Download App Button (PWA) */}
        {showInstallBtn && (
          <motion.button
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={handleInstallClick}
            className="w-full bg-indigo-600 text-white py-3 px-4 rounded-xl flex items-center justify-center gap-3 font-black text-sm tracking-widest shadow-lg shadow-indigo-600/30 border-b-4 border-indigo-800 active:scale-95 transition-all"
          >
            <Download size={20} className="animate-bounce" />
            DOWNLOAD & INSTALL APP
          </motion.button>
        )}

        {/* Banner Slider */}
        <div className="rounded-2xl overflow-hidden shadow-lg">
          {banners.length > 0 ? (
            <BannerSlider banners={banners} />
          ) : (
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="bg-indigo-900 rounded-2xl p-6 text-white text-center relative overflow-hidden shadow-xl border border-white/10 h-36 flex flex-col justify-center"
            >
              <div className="flex justify-between mb-4 absolute top-4 left-4 right-4">
                <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">AUTO DEPOSIT</span>
                <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">AUTO WITHDRAWAL</span>
              </div>
              <p className="text-base font-bold mb-1 leading-tight">जीता हुआ पैसा आप रोजाना Withdrawal कर सकते है</p>
              <p className="text-accent font-black text-xl mb-2 tracking-widest">सुबह 8 बजे से सुबह 11 बजे तक</p>
              <div className="flex items-center justify-center gap-4 text-2xl font-black">
                <span className="text-red-500">♦️</span>
                <span className="text-accent">गुरु</span>
                <span className="text-white">मटका</span>
                <span className="text-red-500">❤️</span>
              </div>
            </motion.div>
          )}
        </div>

        {/* 4 Grid Buttons (From Image 1) */}
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={() => navigate('/add-fund')}
            className="flex flex-col items-center justify-center gap-1 bg-[#00bcd4] text-white py-3 rounded-xl font-bold shadow-lg shadow-cyan-500/20 active:scale-95 transition-all border-b-4 border-cyan-700"
          >
            <PlusCircle size={24} />
            <span className="text-xs font-black uppercase tracking-widest">ADD FUND</span>
          </button>
          <button 
            onClick={() => navigate('/withdraw')}
            className="flex flex-col items-center justify-center gap-1 bg-[#f44336] text-white py-3 rounded-xl font-bold shadow-lg shadow-red-500/20 active:scale-95 transition-all border-b-4 border-red-700"
          >
            <Wallet size={24} />
            <span className="text-xs font-black uppercase tracking-widest">WITHDRAW</span>
          </button>
          <button 
            onClick={() => navigate('/help')}
            className="flex flex-col items-center justify-center gap-1 bg-[#5c6bc0] text-white py-3 rounded-xl font-bold shadow-lg shadow-indigo-600/20 active:scale-95 transition-all border-b-4 border-indigo-800"
          >
            <PlayCircle size={24} />
            <span className="text-xs font-black uppercase tracking-widest">HOW TO PLAY</span>
          </button>
          <a 
            href={SUPPORT_WHATSAPP}
            className="flex flex-col items-center justify-center gap-1 bg-[#00c853] text-white py-3 rounded-xl font-bold shadow-lg shadow-green-500/20 active:scale-95 transition-all border-b-4 border-green-700"
          >
            <MessageSquare size={24} />
            <span className="text-xs font-black uppercase tracking-widest">WHATSAPP</span>
          </a>
        </div>

        {/* Result Banner (Yellow) */}
        <button 
          onClick={() => navigate('/chart')}
          className="w-full bg-[#ffc107] text-dark py-4 px-4 rounded-xl text-center font-black text-xl tracking-widest shadow-lg shadow-yellow-500/20 uppercase border-b-4 border-yellow-700 active:scale-[0.98] transition-all"
        >
          सबसे पहले रिजल्ट देखें।
        </button>

        {/* Refresh/Marquee Banner (Red) */}
        <div className="bg-[#d50000] text-white py-2 px-4 rounded-full flex items-center justify-center gap-2 font-bold text-xs overflow-hidden whitespace-nowrap shadow-lg">
          <RefreshCcw size={14} className="animate-spin-slow shrink-0" />
          <div className="animate-marquee">
            भाईयो सबसे फास्ट पेमेंट मिलेगा ✨ Game play ✨ करो भाईयो सबसे फास्ट पेमेंट मिलेगा ✨ Game play ✨ करो भाईयो
          </div>
        </div>

        {/* Games List */}
        <div className="space-y-3 pt-2">
          {games.length === 0 ? (
            <div className="text-center py-10 text-gray-400 font-bold uppercase tracking-widest italic">
              No active games found
            </div>
          ) : (
            games.map((game) => (
              <div key={game.id}>
                <GameCard game={game} />
              </div>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}
