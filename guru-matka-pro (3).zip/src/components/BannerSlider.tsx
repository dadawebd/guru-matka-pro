import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Banner } from '../types';

interface BannerSliderProps {
  banners: Banner[];
}

export default function BannerSlider({ banners }: BannerSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const getDirectImageUrl = (url: string) => {
    if (url.includes('ibb.co/') && !url.includes('i.ibb.co/')) {
      const parts = url.split('/');
      const id = parts[parts.length - 1];
      return `https://i.ibb.co/${id}/banner.png`;
    }
    return url;
  };

  useEffect(() => {
    if (banners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length]);

  if (banners.length === 0) return null;

  return (
    <div className="relative w-full h-36 rounded-2xl overflow-hidden shadow-xl border border-white/10 bg-indigo-950">
      <AnimatePresence mode="wait">
        <motion.img
          key={banners[currentIndex].id}
          src={getDirectImageUrl(banners[currentIndex].imageUrl)}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.5 }}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://picsum.photos/seed/guru/800/400';
          }}
        />
      </AnimatePresence>
      
      {banners.length > 1 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
          {banners.map((_, idx) => (
            <div
              key={idx}
              className={`h-1.5 rounded-full transition-all ${
                idx === currentIndex ? 'w-6 bg-accent' : 'w-1.5 bg-white/50'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
