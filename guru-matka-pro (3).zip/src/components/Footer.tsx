import React from 'react';
import { Home, History, Share2, HelpCircle } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

export default function Footer() {
  const navigate = useNavigate();
  const location = useLocation();

  const handleShare = async () => {
    const shareData = {
      title: 'Guru Matka',
      text: 'Join Guru Matka - The most trusted Matka app!',
      url: window.location.origin
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        alert('Link copied to clipboard!');
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: History, label: 'History', path: '/bid-history' },
    { icon: Share2, label: 'Share', action: handleShare },
    { icon: HelpCircle, label: 'Help', path: '/help' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-header border-t border-white/10 px-6 py-3 flex items-center justify-between z-50 shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
      {navItems.map((item, index) => (
        <button
          key={index}
          onClick={() => item.path ? navigate(item.path) : item.action?.()}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 ${
            location.pathname === item.path ? 'text-accent' : 'text-white/60'
          }`}
        >
          <item.icon size={20} strokeWidth={location.pathname === item.path ? 3 : 2} />
          <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
        </button>
      ))}
    </div>
  );
}
