import React from 'react';

interface JodiGridProps {
  bids: { [num: string]: string };
  onChange: (num: string, amount: string) => void;
}

export default function JodiGrid({ bids, onChange }: JodiGridProps) {
  const orderedNumbers = Array.from({ length: 100 }, (_, i) => {
    const n = i + 1;
    return n === 100 ? '00' : n.toString().padStart(2, '0');
  });

  return (
    <div className="grid grid-cols-10 gap-1 bg-gray-50 p-1 rounded-xl border border-gray-200 shadow-inner max-h-[60vh] overflow-y-auto">
      {orderedNumbers.map((num) => (
        <div key={num} className="bg-white rounded overflow-hidden border border-gray-200 shadow-sm flex flex-col">
          <div className="bg-header text-white text-[8px] font-black py-0.5 text-center uppercase tracking-tighter">
            {num}
          </div>
          <input
            type="number"
            inputMode="numeric"
            value={bids[num] || ''}
            onChange={(e) => onChange(num, e.target.value)}
            placeholder="0"
            className="w-full py-1 px-0.5 text-center text-[10px] font-bold text-dark focus:outline-none focus:bg-accent/10 transition-colors placeholder:text-gray-200"
          />
        </div>
      ))}
    </div>
  );
}
