import React, { useState } from 'react';
import { Menu, Bell, Home, History, Share2, HelpCircle, User, Wallet, LogOut, X, BarChart2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate, useLocation } from 'react-router-dom';
import { SUPPORT_WHATSAPP } from '../constants';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

import { useAuth } from '../hooks/useAuth';

interface LayoutProps {
  children: React.ReactNode;
  userBalance: number;
}

export default function Layout({ children, userBalance }: LayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { isAdmin } = useAuth();

  const menuItems = [
    { icon: Home, label: 'Dashboard', path: '/' },
    ...(isAdmin ? [{ icon: User, label: 'Admin Panel', path: '/admin' }] : []),
    { icon: BarChart2, label: 'Game Chart', path: '/chart' },
    { icon: User, label: 'User Profile', path: '/profile' },
    { icon: Wallet, label: 'Withdrawal', path: '/withdraw' },
    { icon: History, label: 'Play History', path: '/bid-history' },
    { icon: History, label: 'Win History', path: '/win-history' },
    { icon: Wallet, label: 'Wallet History', path: '/wallet-history' },
    { icon: Wallet, label: 'Rate List', path: '/rates' },
    { icon: HelpCircle, label: 'Help & Support', path: '/help' },
    { icon: Share2, label: 'Share App', action: 'share' },
    { icon: LogOut, label: 'Logout', path: '/logout', action: 'logout' },
  ];

  const bottomNavItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: History, label: 'History', path: '/bid-history' },
    { icon: BarChart2, label: 'Chart', path: '/chart' },
    { icon: Wallet, label: 'Passbook', path: '/wallet-history' },
    { icon: HelpCircle, label: 'Help', path: '/help' },
  ];

  const handleShare = async () => {
    const shareData = {
      title: 'Guru Matka',
      text: 'Join Guru Matka - The most trusted Matka app!',
      url: window.location.origin
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        alert('Link copied to clipboard!');
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col pb-20">
      {/* Header */}
      <header className="bg-header text-white px-4 py-3 flex items-center justify-between sticky top-0 z-40 shadow-md">
        <div className="flex items-center gap-4">
          <button onClick={() => setIsSidebarOpen(true)} className="p-1 active:scale-95 transition-transform">
            <Menu size={28} />
          </button>
          <h1 className="text-xl font-bold tracking-wider">GURU MATKA</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full">
            <span className="text-accent font-bold">₹</span>
            <span className="font-bold">{userBalance}</span>
          </div>
          <button onClick={() => navigate('/notifications')} className="p-1 relative active:scale-95 transition-transform">
            <Bell size={24} />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full border border-header"></span>
          </button>
        </div>
      </header>

      {/* Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 bottom-0 w-72 bg-white z-50 shadow-2xl flex flex-col"
            >
              <div className="bg-header text-white p-6 flex flex-col gap-4">
                <div className="flex justify-between items-start">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <User size={32} />
                  </div>
                  <button onClick={() => setIsSidebarOpen(false)} className="p-1">
                    <X size={24} />
                  </button>
                </div>
                <div>
                  <p className="font-bold text-lg">{auth.currentUser?.displayName || 'Guru Matka User'}</p>
                  <p className="text-white/70 text-sm">{auth.currentUser?.email?.split('@')[0] || 'User'}</p>
                </div>
              </div>

              <nav className="flex-1 overflow-y-auto py-4">
                {menuItems.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      if (item.action === 'logout') {
                        handleLogout();
                      } else if (item.action === 'share') {
                        handleShare();
                      } else {
                        navigate(item.path);
                      }
                      setIsSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-4 px-6 py-4 hover:bg-gray-50 transition-colors ${
                      location.pathname === item.path ? 'text-primary bg-primary/5 border-r-4 border-primary' : 'text-gray-700'
                    }`}
                  >
                    <item.icon size={22} />
                    <span className="font-medium">{item.label}</span>
                  </button>
                ))}
              </nav>

              <div className="p-6 border-t flex justify-center gap-6">
                <a href="#" className="text-pink-600"><Share2 size={24} /></a>
                <a href="#" className="text-blue-600"><Share2 size={24} /></a>
                <a href="#" className="text-red-600"><Share2 size={24} /></a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-header text-white flex justify-around items-center py-2 z-40 shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">
        {bottomNavItems.map((item: any, index) => (
          <button
            key={index}
            onClick={() => {
              if (item.action === 'share') {
                handleShare();
              } else {
                navigate(item.path);
              }
            }}
            className={`flex flex-col items-center gap-1 min-w-[70px] transition-all ${
              location.pathname === item.path ? 'text-accent scale-110' : 'text-white/70'
            }`}
          >
            <item.icon size={22} />
            <span className="text-[10px] font-medium uppercase tracking-wider">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
