import React, { useState, useEffect } from 'react';
import { TrendingUp, Clock } from 'lucide-react';
import { Game } from '../types';
import { useNavigate } from 'react-router-dom';
import { isGameOpen } from '../utils/gameUtils';

interface GameCardProps {
  game: Game;
}

export default function GameCard({ game }: GameCardProps) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(isGameOpen(game.openTime, game.closeTime));

  useEffect(() => {
    const timer = setInterval(() => {
      setIsOpen(isGameOpen(game.openTime, game.closeTime));
    }, 10000); // Check every 10 seconds
    return () => clearInterval(timer);
  }, [game.openTime, game.closeTime]);

  const isPlayable = isOpen;

  const getLocalDate = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // Result logic: If lastResultDate is not today, newResult becomes oldResult and newResult is 00
  const today = getLocalDate();
  const isResultFromToday = game.lastResultDate === today;
  
  const displayOldResult = isResultFromToday ? (game.oldResult || '**') : (game.newResult || '**');
  const displayNewResult = isResultFromToday ? game.newResult : 'Wait';

  const formatTo12Hour = (time: string) => {
    if (!time) return '';
    const [hours, minutes] = time.split(':');
    let h = parseInt(hours);
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    h = h ? h : 12; // the hour '0' should be '12'
    return `${h}:${minutes} ${ampm}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border-2 border-blue-900 overflow-hidden mb-4 transition-all hover:shadow-md active:scale-[0.99] w-full max-w-md mx-auto p-3 flex flex-col items-center relative">
      {/* Game Name */}
      <h3 className="font-black text-lg text-dark uppercase tracking-tight mb-1">
        {game.name}
      </h3>

      {/* Middle Section: Chart, Results, Play */}
      <div className="w-full flex items-center justify-between px-2">
        {/* Left: Yellow Chart Icon */}
        <div className="w-12 h-12 rounded-full bg-yellow-400 flex items-center justify-center shadow-inner border border-yellow-500">
          <TrendingUp size={24} className="text-dark" />
        </div>

        {/* Center: Results & Status */}
        <div className="flex flex-col items-center text-center flex-1 mx-2">
          <div className="flex items-center justify-center gap-1 font-black text-blue-900 tracking-tighter">
            <span className="whitespace-nowrap text-sm opacity-70">{'{'} {displayOldResult} {'}'}</span>
            <span className="text-blue-900 mx-1 opacity-50">→</span>
            <span className="whitespace-nowrap text-2xl">[{displayNewResult}]</span>
          </div>
          <span className={`text-[10px] font-bold uppercase mt-0.5 ${isPlayable ? 'text-green-600' : 'text-red-600'}`}>
            {isPlayable ? 'Market is Running' : 'Market Closed'}
          </span>
        </div>

        {/* Right: Play Button */}
        <button
          onClick={() => isPlayable && navigate(`/play/${game.id}`)}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg border-4 ${
            isPlayable 
              ? 'bg-green-600 text-white border-green-200 hover:scale-110 active:scale-95' 
              : 'bg-red-600 text-white border-red-200 cursor-not-allowed'
          }`}
        >
          <div className="ml-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </button>
      </div>

      {/* Bottom: Times */}
      <div className="mt-2 flex items-center gap-4 text-[11px] font-bold text-blue-900">
        <div className="flex items-center gap-1">
          <span>Open :</span>
          <span className="font-black">{formatTo12Hour(game.openTime)}</span>
        </div>
        <div className="flex items-center gap-1">
          <span>Close :</span>
          <span className="font-black">{formatTo12Hour(game.closeTime)}</span>
        </div>
      </div>
    </div>
  );
}
