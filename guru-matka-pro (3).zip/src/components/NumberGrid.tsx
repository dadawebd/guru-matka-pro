import React from 'react';

interface NumberGridProps {
  selectedNumbers: string[];
  onToggle: (num: string) => void;
  max?: number;
}

export default function NumberGrid({ selectedNumbers, onToggle, max = 100 }: NumberGridProps) {
  const numbers = Array.from({ length: max }, (_, i) => {
    const n = i === 99 && max === 100 ? 0 : i + 1;
    return n.toString().padStart(2, '0');
  });

  // Reorder to match the screenshot (01-10, 11-20, ..., 91-00)
  const orderedNumbers = Array.from({ length: 100 }, (_, i) => {
    const n = i + 1;
    return n === 100 ? '00' : n.toString().padStart(2, '0');
  });

  return (
    <div className="grid grid-cols-10 gap-1 bg-white p-1 border border-primary/20 rounded-lg overflow-hidden">
      {orderedNumbers.map((num) => {
        const isSelected = selectedNumbers.includes(num);
        return (
          <button
            key={num}
            onClick={() => onToggle(num)}
            className={`aspect-square flex items-center justify-center text-xs font-bold transition-all border border-gray-100 ${
              isSelected 
                ? 'bg-primary text-white scale-110 z-10 shadow-md ring-2 ring-primary/30' 
                : 'bg-white text-gray-700 hover:bg-gray-50 active:bg-gray-100'
            }`}
          >
            {num}
          </button>
        );
      })}
    </div>
  );
}
