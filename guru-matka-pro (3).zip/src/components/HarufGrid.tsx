import React from 'react';

interface HarufGridProps {
  title: string;
  selectedNumbers: string[];
  onToggle: (num: string) => void;
}

export default function HarufGrid({ title, selectedNumbers, onToggle }: HarufGridProps) {
  const numbers = Array.from({ length: 10 }, (_, i) => i.toString());

  return (
    <div className="mb-6">
      <h4 className="text-red-matka font-bold text-lg mb-3 flex items-center gap-2">
        {title}
      </h4>
      <div className="grid grid-cols-10 gap-1 bg-white p-1 border border-primary/20 rounded-lg overflow-hidden">
        {numbers.map((num) => {
          const isSelected = selectedNumbers.includes(num);
          return (
            <button
              key={num}
              onClick={() => onToggle(num)}
              className={`aspect-square flex items-center justify-center text-sm font-bold transition-all border border-gray-100 ${
                isSelected 
                  ? 'bg-primary text-white scale-110 z-10 shadow-md ring-2 ring-primary/30' 
                  : 'bg-white text-gray-700 hover:bg-gray-50 active:bg-gray-100'
              }`}
            >
              {num}
            </button>
          );
        })}
      </div>
    </div>
  );
}
