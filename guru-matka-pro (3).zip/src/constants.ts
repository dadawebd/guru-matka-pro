export const GAME_NAMES = [
  'GALI',
  'DISAWAR',
  'DELHI BAZAR',
  'SHREE KARNI',
  'SHREE GANESH',
  'FARIDABAD',
  'GHAZIABAD',
  'VIRAT'
];

export const GAME_RATES = [
  { name: 'Haruf Andar', rate: '10-95' },
  { name: 'Haruf Bahar', rate: '10-95' },
  { name: 'Delhi Jodi', rate: '10-950' }
];

export const SUPPORT_WHATSAPP = 'https://wa.me/918447570123';
export const SUPPORT_CALL = 'tel:+918447570123';
