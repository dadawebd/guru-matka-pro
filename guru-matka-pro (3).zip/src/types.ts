export type GameStatus = 'PLAY' | 'TIME OUT';

export interface Game {
  id: string;
  name: string;
  oldResult: string;
  newResult: string;
  status: GameStatus;
  openTime: string;
  closeTime: string;
  lastTime?: string; // e.g. "00:12:50"
  lastResultDate?: string; // YYYY-MM-DD
}

export interface User {
  uid: string;
  phoneNumber: string;
  walletBalance: number;
  role: 'user' | 'admin';
  name: string;
  mpin: string;
  fcmToken?: string;
  createdAt?: any;
}

export interface Bid {
  id: string;
  userId: string;
  gameId: string;
  gameName: string;
  type: 'JODI' | 'CROSSING' | 'ANDAR' | 'BAHAR';
  numbers: string[];
  amount: number;
  winAmount?: number;
  timestamp: any;
  status: 'PENDING' | 'WIN' | 'LOSS';
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'DEPOSIT' | 'WITHDRAW' | 'WIN' | 'BID' | 'BONUS';
  status: 'PENDING' | 'COMPLETED' | 'REJECTED' | 'APPROVED';
  description: string;
  upiId?: string;
  timestamp: any;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: any;
}

export interface Banner {
  id: string;
  imageUrl: string;
  link?: string;
  timestamp: any;
}

export interface GlobalSettings {
  qrCode: string;
  whatsapp: string;
  upiId: string;
  jodiRate: number;
  harufRate: number;
  paymentMode: 'MANUAL' | 'GATEWAY';
  activeGateways: ('RAZORPAY' | 'CASHFREE' | 'UPIGATEWAY')[];
  razorpayKey?: string;
  razorpaySecret?: string;
  cashfreeAppId?: string;
  cashfreeSecret?: string;
  upiGatewayMerchantId?: string;
  upiGatewayKey?: string;
}
