
export const isGameOpen = (openTime: string, closeTime: string): boolean => {
  if (!openTime || !closeTime) return false;

  const now = new Date();
  const currentHours = now.getHours();
  const currentMinutes = now.getMinutes();
  const currentTimeInMinutes = currentHours * 60 + currentMinutes;

  const [openH, openM] = openTime.split(':').map(Number);
  const [closeH, closeM] = closeTime.split(':').map(Number);

  const openTimeInMinutes = openH * 60 + openM;
  let closeTimeInMinutes = closeH * 60 + closeM;

  // Handle cases where close time is after midnight (e.g. 02:00)
  if (closeTimeInMinutes < openTimeInMinutes) {
    // If current time is after openTime OR before closeTime, it's open
    return currentTimeInMinutes >= openTimeInMinutes || currentTimeInMinutes < closeTimeInMinutes;
  }

  return currentTimeInMinutes >= openTimeInMinutes && currentTimeInMinutes < closeTimeInMinutes;
};

export const getRemainingTime = (closeTime: string): string => {
  if (!closeTime) return '00:00:00';

  const now = new Date();
  const [closeH, closeM] = closeTime.split(':').map(Number);
  
  const closeDate = new Date();
  closeDate.setHours(closeH, closeM, 0, 0);

  if (closeDate < now) {
    closeDate.setDate(closeDate.getDate() + 1);
  }

  const diff = closeDate.getTime() - now.getTime();
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};
