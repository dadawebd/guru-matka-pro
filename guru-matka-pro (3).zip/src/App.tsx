/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import PlayScreen from './pages/Play';
import WalletScreen from './pages/Wallet';
import WalletHistoryScreen from './pages/WalletHistory';
import HistoryScreen from './pages/History';
import AdminDashboard from './pages/Admin';
import Notifications from './pages/Notifications';
import HelpScreen from './pages/Help';
import MonthlyChart from './pages/MonthlyChart';
import ProfileScreen from './pages/Profile';
import RateListScreen from './pages/RateList';
import { useAuth } from './hooks/useAuth';

export default function App() {
  const { isAuthenticated, isAdmin, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-dark flex flex-col items-center justify-center text-white">
        <div className="w-20 h-20 bg-primary rounded-full flex flex-col items-center justify-center mb-8 border-4 border-white/10 shadow-2xl animate-pulse">
          <span className="text-2xl font-black tracking-tighter text-accent">गुरु</span>
          <span className="text-2xl font-black tracking-tighter text-white">मटका</span>
        </div>
        <p className="text-primary font-bold tracking-widest animate-pulse">LOADING...</p>
      </div>
    );
  }

  return (
    <HashRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />

        {/* Protected User Routes */}
        <Route 
          path="/" 
          element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/play/:gameId" 
          element={isAuthenticated ? <PlayScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/add-fund" 
          element={isAuthenticated ? <WalletScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/withdraw" 
          element={isAuthenticated ? <WalletScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/wallet-history" 
          element={isAuthenticated ? <WalletHistoryScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/win-history" 
          element={isAuthenticated ? <HistoryScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/bid-history" 
          element={isAuthenticated ? <HistoryScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/history" 
          element={isAuthenticated ? <WalletHistoryScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/notifications" 
          element={isAuthenticated ? <Notifications /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/help" 
          element={isAuthenticated ? <HelpScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/chart" 
          element={isAuthenticated ? <MonthlyChart /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/profile" 
          element={isAuthenticated ? <ProfileScreen /> : <Navigate to="/login" />} 
        />
        <Route 
          path="/rates" 
          element={isAuthenticated ? <RateListScreen /> : <Navigate to="/login" />} 
        />

        {/* Admin Routes */}
        <Route 
          path="/admin" 
          element={isAuthenticated && isAdmin ? <AdminDashboard /> : <Navigate to="/" />} 
        />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </HashRouter>
  );
}
