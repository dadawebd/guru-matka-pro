import { useState, useEffect } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth, db, requestForToken } from '../firebase';
import { doc, onSnapshot, updateDoc } from 'firebase/firestore';
import { User } from '../types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // User is logged in, fetch their profile from Firestore
        const unsubscribeProfile = onSnapshot(doc(db, 'users', firebaseUser.uid), async (snapshot) => {
          if (snapshot.exists()) {
            const userData = { uid: snapshot.id, ...snapshot.data() } as User;
            setUser(userData);

            // Request push notification token
            if (!userData.fcmToken) {
              const token = await requestForToken();
              if (token) {
                await updateDoc(doc(db, 'users', firebaseUser.uid), {
                  fcmToken: token
                });
              }
            }
          } else {
            setUser(null);
          }
          setLoading(false);
          setIsAuthReady(true);
        }, (error) => {
          console.error('Error fetching user profile:', error);
          setLoading(false);
          setIsAuthReady(true);
        });

        return () => unsubscribeProfile();
      } else {
        // User is logged out
        setUser(null);
        setLoading(false);
        setIsAuthReady(true);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const logout = async () => {
    await signOut(auth);
    setUser(null);
  };

  return { 
    user, 
    loading, 
    isAuthReady,
    isAuthenticated: !!user, 
    isAdmin: user?.role === 'admin' || user?.phoneNumber === '9999999999' || user?.phoneNumber === '8447570123',
    logout
  };
}
