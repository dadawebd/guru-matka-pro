import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  Timestamp,
  setDoc,
  updateDoc,
  increment
} from 'firebase/firestore';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut
} from 'firebase/auth';
import { db, auth } from '../firebase';
import { Game, User, Bid, Transaction, Notification, Banner } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const firebaseService = {
  getGames: (callback: (games: Game[]) => void) => {
    const path = 'games';
    return onSnapshot(collection(db, path), (snapshot) => {
      const games = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Game));
      callback(games);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  },

  getGamesOnce: async () => {
    const path = 'games';
    try {
      const snapshot = await getDocs(collection(db, path));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Game));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  getUser: (uid: string, callback: (user: User | null) => void) => {
    const path = `users/${uid}`;
    return onSnapshot(doc(db, 'users', uid), (snapshot) => {
      if (snapshot.exists()) {
        callback({ uid: snapshot.id, ...snapshot.data() } as User);
      } else {
        callback(null);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
  },

  loginWithMpin: async (phoneNumber: string, mpin: string) => {
    try {
      // Sign out any existing user first to avoid conflicts
      try {
        await signOut(auth);
      } catch (e) {
        console.warn('Sign out failed:', e);
      }

      const email = `${phoneNumber}@guru.com`;
      // Pad MPIN to satisfy Firebase Auth's 6-character minimum requirement
      const paddedMpin = mpin.padStart(6, '0');
      
      const result = await signInWithEmailAndPassword(auth, email, paddedMpin);
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      if (!userDoc.exists()) {
        throw new Error('User profile not found. Please register again.');
      }
      return { uid: userDoc.id, ...userDoc.data() } as User;
    } catch (error: any) {
      console.error('Login error:', error);
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        throw new Error('Invalid Mobile Number or MPIN');
      }
      if (error.code === 'auth/network-request-failed') {
        throw new Error('Network error. Please check your internet connection.');
      }
      if (error.code === 'auth/operation-not-allowed') {
        throw new Error('Login is DISABLED. Please enable "Email/Password" in Firebase Console > Authentication > Sign-in method.');
      }
      throw error;
    }
  },

  registerWithMpin: async (phoneNumber: string, name: string, mpin: string) => {
    try {
      // Sign out any existing user first to avoid conflicts
      try {
        await signOut(auth);
      } catch (e) {
        console.warn('Sign out failed:', e);
      }
      
      // Small delay to ensure auth state is cleared
      await new Promise(resolve => setTimeout(resolve, 500));

      const email = `${phoneNumber}@guru.com`;
      // Pad MPIN to satisfy Firebase Auth's 6-character minimum requirement
      const paddedMpin = mpin.padStart(6, '0');
      
      // Create user in Firebase Auth first. 
      const result = await createUserWithEmailAndPassword(auth, email, paddedMpin);
      const uid = result.user.uid;

      // Create user profile in Firestore
      try {
        const isAdmin = phoneNumber === '9999999999' || phoneNumber === '8447570123';
        await setDoc(doc(db, 'users', uid), {
          uid,
          phoneNumber,
          name,
          mpin, // Store the original MPIN in Firestore
          walletBalance: isAdmin ? 1000000 : 0,
          role: isAdmin ? 'admin' : 'user',
          createdAt: Timestamp.now()
        });
      } catch (firestoreError) {
        console.error('Firestore profile creation failed:', firestoreError);
        // If profile creation fails, we should probably delete the auth user to allow retry
        // but for now, we'll just throw a descriptive error
        throw new Error('User created but profile setup failed. Please contact support.');
      }
      
      return uid;
    } catch (error: any) {
      console.error('Registration error:', error);
      if (error.code === 'auth/email-already-in-use') {
        throw new Error('Mobile Number already registered. Please Login.');
      }
      if (error.code === 'auth/network-request-failed') {
        throw new Error('Network error. Please check your internet connection.');
      }
      if (error.code === 'auth/operation-not-allowed') {
        throw new Error('Registration is DISABLED. Please enable "Email/Password" in Firebase Console > Authentication > Sign-in method.');
      }
      throw error;
    }
  },

  loginAsDemo: async () => {
    const demoPhone = '0000000000';
    const demoMpin = '1234';
    const demoName = 'Demo User';
    
    try {
      // Try to login first
      return await firebaseService.loginWithMpin(demoPhone, demoMpin);
    } catch (error: any) {
      // If user not found, register them automatically
      if (error.message.includes('Invalid Mobile Number') || error.message.includes('not found')) {
        try {
          await firebaseService.registerWithMpin(demoPhone, demoName, demoMpin);
          return await firebaseService.loginWithMpin(demoPhone, demoMpin);
        } catch (regError) {
          console.error('Demo registration failed:', regError);
          throw new Error('Demo login failed. Please try manual registration.');
        }
      }
      throw error;
    }
  },
  
  requestDeposit: async (userId: string, amount: number) => {
    const path = 'transactions';
    try {
      const docRef = await addDoc(collection(db, path), {
        userId,
        amount,
        type: 'DEPOSIT',
        status: 'PENDING',
        description: 'Deposit via QR Code',
        timestamp: Timestamp.now()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  requestWithdraw: async (userId: string, amount: number, upiId: string) => {
    const path = 'transactions';
    try {
      // Check balance first
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (!userDoc.exists()) throw new Error('User not found');
      const userData = userDoc.data() as User;
      if (userData.walletBalance < amount) throw new Error('Insufficient balance');

      // Create a pending withdrawal transaction
      const docRef = await addDoc(collection(db, path), {
        userId,
        amount,
        type: 'WITHDRAW',
        status: 'PENDING',
        description: `Withdrawal to UPI: ${upiId}`,
        upiId,
        timestamp: Timestamp.now()
      });

      // Deduct balance immediately to prevent double spending
      await updateDoc(doc(db, 'users', userId), {
        walletBalance: increment(-amount)
      });

      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  placeBid: async (bidData: Omit<Bid, 'id' | 'timestamp' | 'status'>) => {
    const path = 'bids';
    try {
      // Check balance first
      const userDoc = await getDoc(doc(db, 'users', bidData.userId));
      if (!userDoc.exists()) throw new Error('User not found');
      const userData = userDoc.data() as User;
      if (userData.walletBalance < bidData.amount) throw new Error('Insufficient balance');

      // Deduct balance
      await updateDoc(doc(db, 'users', bidData.userId), {
        walletBalance: increment(-bidData.amount)
      });

      // Add bid
      const bidRef = await addDoc(collection(db, path), {
        ...bidData,
        timestamp: Timestamp.now(),
        status: 'PENDING'
      });

      // Add transaction
      await addDoc(collection(db, 'transactions'), {
        userId: bidData.userId,
        amount: bidData.amount,
        type: 'BID',
        status: 'COMPLETED',
        description: `Bid on ${bidData.gameName} (${bidData.type})`,
        timestamp: Timestamp.now()
      });

      return bidRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  placeBids: async (userId: string, gameId: string, gameName: string, bids: { number: string, amount: number }[]) => {
    const totalAmount = bids.reduce((sum, b) => sum + b.amount, 0);
    const userRef = doc(db, 'users', userId);
    
    try {
      // Check balance
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) throw new Error('User not found');
      const userData = userDoc.data() as User;
      if (userData.walletBalance < totalAmount) throw new Error('Insufficient balance');

      // Deduct total balance
      await updateDoc(userRef, {
        walletBalance: increment(-totalAmount)
      });

      // Add all bids
      const bidPromises = bids.map(bid => 
        addDoc(collection(db, 'bids'), {
          userId,
          gameId,
          gameName,
          type: 'JODI',
          numbers: [bid.number],
          amount: bid.amount,
          timestamp: Timestamp.now(),
          status: 'PENDING'
        })
      );

      await Promise.all(bidPromises);

      // Add one summary transaction
      await addDoc(collection(db, 'transactions'), {
        userId,
        amount: totalAmount,
        type: 'BID',
        status: 'COMPLETED',
        description: `Bids on ${gameName} (Total ${bids.length} Jodis)`,
        timestamp: Timestamp.now()
      });

      return true;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'bids');
    }
  },

  getBids: (userId: string, callback: (bids: Bid[]) => void) => {
    const path = 'bids';
    const q = query(collection(db, path), orderBy('timestamp', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const bids = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Bid))
        .filter(bid => bid.userId === userId);
      callback(bids);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  },

  getTransactions: (userId: string, callback: (transactions: Transaction[]) => void) => {
    const path = 'transactions';
    const q = query(collection(db, path), orderBy('timestamp', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const transactions = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as Transaction))
        .filter(tx => tx.userId === userId);
      callback(transactions);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  },

  getNotifications: (callback: (notifications: Notification[]) => void) => {
    const path = 'notifications';
    const q = query(collection(db, path), orderBy('timestamp', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const notifications = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      callback(notifications);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  },

  getBanners: (callback: (banners: Banner[]) => void) => {
    const path = 'banners';
    const q = query(collection(db, path), orderBy('timestamp', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const banners = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Banner));
      callback(banners);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  }
};
