import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.gurumatka.app',
  appName: 'Guru Matka',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
